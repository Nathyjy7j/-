
use Dugma2


drop table sikumhazmanot
create table sikumhazmanot
(siduri int identity(1,1) primary key, 
yom date,
mocherid int, 
mechir float,
kamut int
);

-- =-=-=-=-=-=-=-=-=-=
insert into sikumhazmanot values
('01-02-1998', 1, 8.7, 13),
('01-02-1998', 2, 3.2, 85),
('01-02-1998', 2, 18.6, 6),
('01-02-1998', 2, 81.2, 27),
('01-03-1998', 1, 32.0, 82),
('01-03-1998', 2, 7.2, 85),
('01-03-1998', 1, 4.7, 49),
('01-04-1998', 1, 23.7, 52),
('02-04-1998', 1, 67.4, 52),
('02-04-1998', 2, 34.3, 16),
('02-05-1998', 2, 100.0, 1),
('02-05-1998', 3, 200.0, 5)
;

select * from sikumhazmanot
select sum(mechir*kamut) from sikumhazmanot


-- use of variables
select * from sikumhazmanot


declare @mechira float
set @mechira = (select sum(mechir*kamut) from sikumhazmanot)  -- takes result of () as value!
select @mechira
--OR
declare @mechira float = (select sum(mechir*kamut) from sikumhazmanot)
--select @mechira

declare @yaad int
set @yaad = 12500

if @mechira > @yaad 
	begin
		select 'good' 
	end
else
	begin
		select 'too low'
	end


-- put it in a function
drop procedure sikumyomi

create procedure sikumyomi
as
begin
 declare @mechira float = (select sum(mechir*kamut) from sikumhazmanot)
 --select @mechira
 declare @yaad int = 12000
 if @mechira > @yaad
	begin
		select 'good'
	end
 else
	begin
		select 'too low'
	end
end

--look at GUI that it is created


--call the procedure
execute sikumyomi

exec sikumyomi

sikumyomi



select mocherid, sum(mechir*kamut) from sikumhazmanot 
group by mocherid


-- PROCEDURES with arguments
select * from sikumhazmanot where mocherid = 1
select sum(mechir*kamut) from sikumhazmanot where mocherid = 1
-- goal: get all details

--drop procedure PersonalMechoriot 
create procedure PersonalMechoriot @mocher int
as								   -- this takes an argument!
begin
  select @mocher as MisparMocher, sum(mechir*kamut) from sikumhazmanot where mocherid = @mocher
end


-- two calls to the procdure using arguments
exec PersonalMechoriot @mocher = 1
exec PersonalMechoriot @mocher = 3
--exec PersonalMechoriot @mocher = 4

--targilim 10.1 10.2 10.3


-- while
-- GOAL: select * from sikumhazmanot where mocherid = 1, 2, 3

-- if I know how many mochrim there are
declare @thismocher int = 1
while @thismocher  <= 3
	begin
		exec PersonalMechoriot @mocher = @thismocher
		set @thismocher  = @thismocher + 1
	end


-- if I don't know.....:
-- first step:
-- how many mochrim are in the db?
select mocherid from sikumhazmanot
select distinct mocherid from sikumhazmanot
select count(distinct mocherid) from sikumhazmanot


-- second step: loop through all of them
declare @kamamochrim int
set @kamamochrim = (select count(distinct mocherid) from sikumhazmanot) -- takes result of () as value!
--select @kamamochrim 
declare @thismocher int
set @thismocher = 1 
while @thismocher  <= @kamamochrim
	begin
		exec PersonalMechoriot @mocher = @thismocher
		set @thismocher  = @thismocher + 1
	end



-- with break
--select distinct mocherid from sikumhazmanot
--select count(distinct mocherid) from sikumhazmanot
declare @kamamochrim int
set @kamamochrim = (select count(distinct mocherid) from sikumhazmanot)
--select @kamamochrim 
declare @thismocher int
set @thismocher = 1 
while @thismocher  <= @kamamochrim
	begin
	  exec PersonalMechoriot @mocher = @thismocher
		 if @thismocher  = 2 break
	  set @thismocher  = @thismocher + 1
	end






-- a procedure with input AND output arguments
-- like "return"

-- drop procedure PersonalMechoriotWithPelet like "return"
create procedure PersonalMechoriotWithPelet @mocher int, @yomit float output
as
begin
set @yomit = 
	(select sum(mechir*kamut) from sikumhazmanot where mocherid = @mocher )
end

-- run it with arguments

declare @kamamochrim int
set @kamamochrim = (select count(distinct mocherid) from sikumhazmanot) -- takes result of () as value!
declare @thismocher int
set @thismocher = 1 
declare @peletyomi float
while @thismocher  <= @kamamochrim
begin
  exec PersonalMechoriotWithPelet @thismocher , @peletyomi output
  select @peletyomi
  set @thismocher  = @thismocher + 1
end 




------------

-- case
-- select * from sikumhazmanot

select *,
case
	when kamut > 75 then 'tov'		-- pay attention to the order!
	when kamut > 50 then 'kacha kacha'
	else 'al hapanim'
	end 
	as Haaracha,
case 
	when kamut * mechir > 1000 then 'alakefak!'
	else 'basa'
	end
	as Tacheles
from sikumhazmanot 


-- another example
select * from shlifot

select chanut, 
case
	when ktovet like '%vot' or ktovet like '%sheva' then 'darom'
	when ktovet like '%saba' or ktovet like '%holon' then 'merkaz'
	else 'zafon'
end
as ezor
from shlifot 

alter table shlifot add ezor nvarchar(20)
update shlifot set ezor = 
case
	when ktovet like '%vot' or ktovet like '%sheva' then 'darom'
	when ktovet like '%saba' or ktovet like '%holon' then 'merkaz'
	else 'zafon'
end
select * from shlifot

