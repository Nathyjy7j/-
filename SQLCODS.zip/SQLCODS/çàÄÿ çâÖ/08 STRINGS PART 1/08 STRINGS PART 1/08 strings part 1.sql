

use Dugma2

--drop table sugim
create table sugim
(shever float,
esroni decimal(5,2),
echedefes bit
)
select * from sugim
insert into sugim values (10.1, 33.33, 0)
insert into sugim values (10, 333, 1)
insert into sugim values (10.1, 333.33, 2)
--insert into sugim values (10.1, 3333.33, 1)
--insert into sugim values (10.1, 3.333, 1)   -- cuts after second number

select * from sugim



-- drop table sismaot

create table sismaot
(
shem nvarchar(50),
doal nvarchar(50),
sisma nvarchar(50)
);


insert into sismaot values
('udi', 'Udi@Gmail.com', 'Abcd1234'),
('odelia', 'odel@JerusalemCity.co.il', 'AAbbccdd12'),
('ofer', 'ofer123@GMAIL.com', 'Sisma@sheli'),
('tali', '       tali.cohen@gmail.com', 'CohenTali98'),
('rami', 'rami#microsoft.com', '12121!'),
('eti', 'eti007@bezeqint.net         ', '007eti007'),
('levana', 'levanaJerusalemCity.co.il', 'Levana01'),
('assi', 'ASSI007@walla.co.il', 'assi07'),
('lev', 'halev@hagadol@gmail.com', 'levlevlev'),
('hadasa', 'hadasa@walla.co.il', '1234hadasa')
;


select * from sismaot

--LEN (length)
select len('abcd')
-- give those sismaot that are too short
select len(sisma) from sismaot
select sisma, len(sisma) from sismaot
select sisma, len(sisma) as OrechSisma from sismaot

select * from sismaot
where len(sisma) < 8

select *, len(sisma) as OrechSisma from sismaot
where len(sisma) < 8




-- LEFT
select *, left(doal,3) as smola3 from sismaot
-- give all sismaot starting with A (or 'a')
select * from sismaot
where left(sisma,1) = 'a'


--RIGHT
-- give all sismaot from gmail.com (no UPPER cases) 

select * from sismaot 
where right(doal,9) ='gmail.com'

--select *, right(doal,9) from sismaot


-- count them
select count(doal) from sismaot 
where right(doal,9) = 'gmail.com'
--function "right" in both select (extra column) and where (condition)
select *, right(doal,9) as Gmaildomain from sismaot
where right(doal,9) = 'gmail.com'



-- TRIM, LTRIM, RTRIM
-- delete leading blanks in strings
-- select before and after to see the differences

select *, len(doal) from sismaot
update sismaot 
set doal = TRIM(doal)
select *, len(doal) from sismaot



-- LOWER, UPPER
select LOWER('A')
select UPPER('a')
-- delete UPPER cases from emails
select * from sismaot
update sismaot
set doal = LOWER(doal)
select * from sismaot



-- give the first place (number) of @ in mail. 
-- Also: check if there is @ at all! Returns 0 if there's no @.
select *, CHARINDEX('@',doal) as kruchit from sismaot

select * from sismaot
where CHARINDEX('@',doal) = 0


-- give the different mail domains
-- here the length of the domain is not known!
select 
	*, right(doal,LEN(doal) - charindex('@',doal)) as HaDomainim
   from sismaot
 

/*   
-- e.g. udi@gmail.com: 
select doal from sismaot where doal = 'udi@gmail.com' 						-- udi@gmail.com
select doal, LEN(doal) from sismaot where doal = 'udi@gmail.com'     		-- 13
select doal, CHARINDEX('@',doal) from sismaot where doal = 'udi@gmail.com' 	--4
select doal, LEN(doal) - CHARINDEX('@',doal) 
	from sismaot where doal = 'udi@gmail.com'  								-- 13 - 4 = 9
select right(doal,9) from sismaot where doal = 'udi@gmail.com'				-- gmail.com
*/

-- give the different mail domains - without duplicates. and order them

select distinct 
   right(doal,LEN(doal)-charindex('@',doal)) as HaDomainim
   from sismaot
   order by HaDomainim  
--   order by right(doal,LEN(doal)-charindex('@',doal)) 


--count them - use group by
select 
	right(doal,LEN(doal)-charindex('@',doal)) as HaDomainim,
	count(*) as KamaMikolDomain
   from sismaot
   group by right(doal,LEN(doal)-charindex('@',doal)) 




-- charindex with three arguments
select *, CHARINDEX('@',doal) as kruchit from sismaot
select *, CHARINDEX('@',doal, 7) as kruchit from sismaot

select *, CHARINDEX('@',doal), CHARINDEX('@',doal, 6) as kruchitfrom6 from sismaot


-- find the second shtrudel
select * from sismaot where CHARINDEX('@', doal, CHARINDEX('@',doal)+1) > 0 
select * from sismaot where CHARINDEX('@', 
									   doal, 
									   CHARINDEX('@',doal)+1) > 0 


-- where to be found
select *, 
	CHARINDEX('@', doal, CHARINDEX('@',doal)+1) as Mikum
	from sismaot where CHARINDEX('@', doal, CHARINDEX('@',doal)+1) > 0 



-- give the from letter 2 and go on 4 letters
select *, SUBSTRING(sisma, 2, 4) as tatmachrozet from sismaot


-- give the part of the email until @
select
	*, 
	SUBSTRING(doal,0,CHARINDEX('@',doal)) 
  from sismaot


-- give the part of the mail from the @, without the @
select
	*, 
	SUBSTRING(doal,CHARINDEX('@',doal)+1, len(doal))  
  from sismaot



-- dugma lematala
drop table nayadim
create table nayadim
(mispar nvarchar(20))

insert into nayadim values
('0987654321'),
('0051123445'),
('0501'),
('0501234567'),
('0501111111111111'),
('050 1234567')

select * from nayadim

alter table nayadim add nifsal nvarchar(30)
select * from nayadim

update nayadim set nifsal = 'too short' where len(mispar) < 10
update nayadim set nifsal = 'starts bad' where left(mispar,2) != '05'
-- etc.....
select * from nayadim
select COUNT(*) from nayadim where nifsal IS NULL
select COUNT(*) from nayadim where nifsal IS NOT NULL
select count(*) from nayadim where len(nifsal) > 0



