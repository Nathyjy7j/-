
use haovdim

--- ****************************************************************************
--HATSAGAT NETUNIM
--1.1
select * from haovdim 
--1.2
select * from haovdim where machlaka = 1
--1.3
select * from haovdim where maskoret > 11000 and machlaka = 3
--1.4
select * from haovdim where maskoret between 11000 and 12000
--1.5
select * from haovdim where maskoret < 11000 or maskoret > 12000
--1.6
select prati, mishpacha, doal from haovdim
--1.7
select * from haovdim where doal like '%gmail.com'
--1.8
select * from haovdim where machlaka = 1 order by mishpacha
--1.9
select * from haovdim order by machlaka desc, prati 
--1.10
select  top 3 * from haovdim order by maskoret desc
--1.11
select * from haovdim where maskoret > 19000
--1.12
select distinct machlaka from haovdim 



--CHANGES 2
--2.1
update haovdim set mishpacha = 'Cohen' where prati = 'Oshra' and mishpacha = 'Beer'

--2.2
select * from haovdim where maskoret < 7500
update haovdim set maskoret = maskoret * 1.1 where maskoret < 7500

--2.3
alter table haovdim add bonus int

--2.3.1
update haovdim set bonus = 1 where machlaka = 1
--select * from haovdim
--2.3.2
alter table haovdim drop column bonus

--2.4
delete from haovdim where tikishi > 390



-- BAKAROT 3
--3.1
alter table haovdim add siduri int primary key identity(1,1)
select * from haovdim

--3.2
--select * from haovdim where maskoret < 8000
ALTER table haovdim ADD CHECK (maskoret >= 8000);

--3.2.1
update haovdim set maskoret = 8000 where maskoret < 8000
ALTER table haovdim ADD CHECK (maskoret >= 8000);

--3.2.2
insert into haovdim values 
('Hana','Shapira',451,'hanshap@comcast.net','1982-02-07',1,7119);
--should give error


--3.3
ALTER table haovdim ADD UNIQUE (tikishi);

--3.3.1
select * from haovdim where tikishi = 21
update haovdim set tikishi = 22 where siduri = 96

ALTER table haovdim ADD UNIQUE (tikishi);
select * from haovdim where tikishi = 181
update haovdim set tikishi = 182 where siduri = 19

ALTER table haovdim ADD UNIQUE (tikishi);
select * from haovdim where tikishi = 287
update haovdim set tikishi = 288 where siduri = 136

ALTER table haovdim ADD UNIQUE (tikishi);

--3.3.2
update haovdim set tikishi = 288 where siduri = 137


--3.4
--alter table haovdim drop column bonusim
alter table haovdim add bonusim int 
	check (bonusim < 6)
select * from haovdim

update haovdim set bonusim = 6 where tikishi between 40 and 60



-- AGGREGRATE
--4.1
select count(*) from haovdim where machlaka = 3


--4.2
select avg(maskoret) from haovdim

--4.3
select SUM(maskoret) from haovdim where machlaka = 1

--4.4
select MIN(maskoret) from haovdim where tikishi between 200 and 300

--4.5
select machlaka, AVG(maskoret) from haovdim
group by machlaka

--4.6
alter table haovdim
add vetek nvarchar (10)
--alter table haovdim drop column vetek
update haovdim set vetek = 'vatik' where tikishi < 150
update haovdim set vetek = 'benoni' where tikishi between 150 and 300
update haovdim set vetek = 'chadash' where tikishi > 300
--select * from haovdim

--4.6.1
select count(*) from haovdim where vetek = 'chadash' and machlaka=4

--4.6.2
select max(maskoret) from haovdim where vetek = 'benoni'

--4.6.3
select vetek, avg(maskoret) from haovdim
group by vetek
having avg(maskoret) > 11000
--where avg(maskoret) > 10000  -- WRONG!!!

----4.6.4
select vetek, max(maskoret) from haovdim
group by vetek
order by max(maskoret) desc
select vetek, max(maskoret) from haovdim
group by vetek
--order by max(maskoret) 



--- ****************************************************************************
-- ICHUD
-- 5.1
--drop table menahalim

create table menahalim
(
siduri int identity(1,1) primary key,
menahelshem nvarchar(20),
menahelmishp nvarchar(20),
menahelmachlaka int
);

insert into menahalim values
('matan ', 'atari ', 1),
('gavriel ', 'levi ', 2),
('shani ', ' helinger', 3),
(' maayan', ' gold', 4)
;


-- 5.2.1
--select * from haovdim where prati = 'Rut' and mishpacha = 'Backer'
select menahelshem
from haovdim, menahalim
where menahalim.menahelmachlaka = haovdim.machlaka and prati = 'Rut' and mishpacha = 'Backer'

--or

select menahelshem
from haovdim inner join menahalim
	on menahalim.menahelmachlaka = haovdim.machlaka
where prati = 'Rut' and mishpacha = 'Backer'



-- 5.2.2
--select top 1 * from haovdim order by maskoret desc
select top 1 menahelshem
from haovdim, menahalim
where menahalim.menahelmachlaka = haovdim.machlaka
order by maskoret desc
select * from menahalim

-- 5.2.3
select  prati, mishpacha, menahelshem --, tikishi
from haovdim, menahalim
where menahalim.menahelmachlaka = haovdim.machlaka
and tikishi between 50 and 100


-- 5.3
--drop table hovot
create table hovot
(
siduri int identity(1,1) primary key,
misparoved int,
chov int 
);

insert into hovot values
(49, 2000),
(33, 19000),
(17, 21500),
(117, 2000),
(49, 5000),
(91, 28900),
(53, 12000),
(3, 5300),
(93, 3000),
(122, 7777);

select * from hovot

-- 5.4

select menahelshem, chov
from haovdim, menahalim, hovot
where hovot.misparoved = haovdim.siduri and menahalim.menahelmachlaka = haovdim.machlaka 


-- 5.5
select menahelshem, count(chov) as Misparhalvatot, sum(chov) as SchumKolel 
from haovdim, menahalim, hovot
where hovot.misparoved = haovdim.siduri and menahalim.menahelmachlaka = haovdim.machlaka 
group by menahelshem


-- 6.1
alter table hovot add check (chov<30000)
--insert into hovot values (149, 30001)

-- 6.2
select * from hovot
alter table hovot
add foreign key (misparoved) references haovdim(siduri);


-- 6.3A
insert into hovot values
(501, 2000);
--select * from haovdim

-- 6.3B
delete from haovdim where siduri = 49

-- 6.3C
delete from hovot where misparoved = 49
delete from haovdim where siduri = 49

