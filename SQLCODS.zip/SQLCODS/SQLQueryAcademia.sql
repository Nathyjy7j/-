--- מחרוזות
create table sugim
(
shever float,
esroni decimal(5,2),
--המספר הראשון 5 הוא כמה מספרים בכלל אפשר להכניס
--המספר השני הוא כמה מספרים לפני הנקודה אפשר להכניס 
--
echedefes bit
--משתנה מסוג בולאני של אחד זה נכון ואפס זה שקר , כל מספר אחר שיכתבו אותו
)
select * from sugim
insert into sugim values (10.1, 33.33, 0)
insert into sugim values (10, 333, 1)
insert into sugim values (10.1, 333.33, 2)
--insert into sugim values (10.1, 3333.33, 1)
--insert into sugim values (10.1, 3.333, 1)

- drop table sismaot

create table sismaot
(
shem nvarchar(50),
doal nvarchar(50),
sisma nvarchar(50)
);
insert into sismaot values
('udi', 'Udi@Gmail.com', 'Abcd1234'),
('odelia', 'odel@JerusalemCity.co.il', 'AAbbccdd12'),
('ofer', 'ofer123@GMAIL.com', 'Sisma@sheli'),
('tali', '       tali.cohen@gmail.com', 'CohenTali98'),
('rami', 'rami#microsoft.com', '12121!'),
('eti', 'eti007@bezeqint.net         ', '007eti007'),
('levana', 'levanaJerusalemCity.co.il', 'Levana01'),
('assi', 'ASSI007@walla.co.il', 'assi07'),
('lev', 'halev@hagadol@gmail.com', 'levlevlev'),
('hadasa', 'hadasa@walla.co.il', '1234hadasa')
;
---leb אורך

--מראה את האורך של המילה  len המילה 
select len('abcd')
--מראה את האורך של הסיסמאות
select len(sisma) from sismaot
--מראה את הסיסמה ואת האורך שלה 
select sisma, len(sisma) from sismaot
--שאילתה שמראה את נתונים של הטבלה שהאורך הוא קטן מי 8
select * from sismaot
where len(sisma) < 8
-- left שמאל
--מראה את השלוש התווים משמאל
-- ולכן בשורה 4 התוצה היא רק בגלל שהשלוש תווים משמאל לימין הם רקים
select doal, left(doal,3) as smola3 from sismaot
--a מראה את הסיסמה שהתו הכי שמאלי שלה הוא 
-- זה כולל גם אותיות קטנות וגם גדולות
select * from sismaot
where left(sisma,1) = 'a'

--right ימינה
--מראה לי את האימייל שה9 מתווים מימין לשמאל הם 
--gmail.com
select * from sismaot 
where right(doal,9) ='gmail.com'
--עוד תצורה של הקוד אם שאלת איסוף
select *, right(doal,9) as Gmaildomain from sismaot
where right(doal,9) = 'gmail.com'

--מראה לי את כל ה9 תווים מימיןלשמאל
select  right(doal,9) from sismaot

--הסרת רווחים
-- TRIM,LTRIM , RTRIM
--מסיר את כל רווחים TRIM 
--מסי רק את הרווחים משאל עד שהוא מגיע לתו כלשהו LTRIM
-- מסר רווחים רק מימין עד שהוא מגיע לתו כלשהו RTRIM

-- delete leading blanks in strings
-- select before and after to see the differences

--TRIM 
-- עדכון טבלה
update sismaot 
set doal = TRIM(doal)

select doal, len(doal) from sismaot

--RTRIM
insert into sismaot values
('udi', 'Udi@Gmail.com   ', 'Abcd1234')

select doal, right(doal,4) from sismaot

--עדכון טבלה
update sismaot 
set doal = RTRIM(doal)

select doal, len(doal) from sismaot

--LTRIM
insert into sismaot values
('udi', '   Udi@Gmail.com', 'Abcd1234')

select doal, left(doal,4) from sismaot

--עדכון טבלה
update sismaot 
set doal = LTRIM(doal)

select doal, len(doal) from sismaot



-- LOWER, UPPER
--מקבל אות גדולה באנגלית והופכת אותה לקטנה LOWER
--מקבלת אות קטנה באנגלית והופכת אותה לגדולה UPPER
select LOWER('A')
select UPPER('a')

-- מראה את השמות
select sisma from sismaot

-- עדכון להפוך את כל האותיות של השמות לאותיות גדולות
update sismaot
set sisma = UPPER(sisma)

-- מראה את השמות
select sisma from sismaot

--עדכון להפוך את כל האותיות של השמות לאותיות קטנות
update sismaot
set sisma = LOWER(sisma)

-- מראה את השמות
select sisma from sismaot


--סופר כמה תווים עברנו כדי למצוא את התו שהכנסו  CHARINDEX 
select *, CHARINDEX('@',doal) as kruchit from sismaot

--@ שאילתה שמראה לנו את המאיליים שיש בהם את התוו 
select * from sismaot
where CHARINDEX('@',doal) != 0 


    ----0-!!!!!!!!!!לא שלם---------------------------
--
select  right(doal,LEN(doal) - charindex('@',doal)) 
--
--
--
as HaDomainim
   from sismaot

-- find the second shtrudel
select * from sismaot where CHARINDEX('@', doal, CHARINDEX('@',doal)+1) > 0 
select * from sismaot where CHARINDEX('@', 
									   doal, 
									   CHARINDEX('@',doal)+1) > 0
-- where to be found
select *, 
	CHARINDEX('@', doal, CHARINDEX('@',doal)+1) as Mikum
	from sismaot where CHARINDEX('@', doal, CHARINDEX('@',doal)+1) > 0 

-- give the from letter 2 and go on 4 letters
select *, SUBSTRING(sisma, 2, 4) as tatmachrozet from sismaot


-- give the part of the email until @
select
	*, 
	SUBSTRING(doal,0,CHARINDEX('@',doal)) 
  from sismaot


-- give the part of the mail from the @, without the @
select
	*, 
	SUBSTRING(doal,CHARINDEX('@',doal)+1, len(doal))  
  from sismaot

-- dugma lematala
drop table nayadim
create table nayadim
(mispar nvarchar(20))

insert into nayadim values
('0987654321'),
('0051123445'),
('0501'),
('0501234567'),
('0501111111111111'),
('050 1234567')
select * from nayadim
alter table nayadim add nifsal nvarchar(30)
select * from nayadim
update nayadim set nifsal = 'too short' where len(mispar) < 10
update nayadim set nifsal = 'starts bad' where left(mispar,2) != '05'
-- etc.....
select * from nayadim
select COUNT(*) from nayadim where nifsal IS NULL
select COUNT(*) from nayadim where nifsal IS NOT NULL
select count(*) from nayadim where len(nifsal) > 0
-------------------------------------------------


---------שאלות ותשובות מכללה
--1.	הגדר מסד נתונים , ותעבור אליו
create database TexT
use TexT
--2.	הגדר טבלה העונה על דרישת החברה
create table artist(
name nvarchar(30),
song nvarchar(30),
numbersong int,
likes int
);



--3.(תמלא את הטבלה בנתוני-דמה (מדמיונך הפורה
insert into artist values
('ביבי','אין  כלום',122,8000),
('בן גביר','רובה לכולם',233,9000),
('דובר צהל','שאלות יש',2422,10000),
('טראפ','הכסף מדבר',3343,50000),
('בני גנץ','אין לי מוח',22343,600);

--4.	הגדר שאילתה המציגה את כל הנתונים שהוכנסו למסד הנתונים
select * from artist 

--5.	הגדר שאילתה המציגה את שם האומן וכן את מספר הלייקים של כל הרשומות 
select name, likes from artist 


--drop database haovdim
--create database haovdim
--use haovdim
--drop table haovdim
--drop table hovot


--drop table haovdim

create table haovdim
(
prati nvarchar(30),
mishpacha nvarchar(30),
tikishi int,
doal nvarchar(30),
leda date,
machlaka int,
maskoret int
)


insert into haovdim values
('Noach','Bashevis',81,'smeier@gmail.com','1971-04-04',1,9123),
('Gabriel','Zangwill',205,'heine@optonline.net','1976-07-08',3,12409),
('Nathan','Mond',129,'seurat@me.com','1973-04-17',2,10395),
('Tomas','Blomstein',147,'sumdumass@live.com','1974-01-21',3,10872),
('Davin','Pirbright',93,'gslondon@comcast.net','1971-10-07',2,9441),
('Osnat','Zundel',337,'jhardin@comcast.net','1982-02-13',3,15907),
('Rut','Backer',325,'jrifkin@aol.com','1981-08-11',3,15589),
('Shlomit','Myers',307,'panolex@att.net','1980-11-05',3,15112),
('Riva','Katz',321,'devphil@verizon.net','1981-06-10',3,15483),
('Shelly','Gartner',249,'afeldspar@icloud.com','1978-05-21',3,13575),
('Benjamin','Spector',11,'bolow@msn.com','1968-04-14',1,7268),
('Noya','Shalick',279,'mfleming@hotmail.com','1979-08-29',3,14370),
('Gian','Rosen',185,'keiji@att.net','1975-09-02',3,11879),
('Irina','Straus',225,'bolow@sbcglobal.net','1977-05-14',3,12939),
('Yehoshua','Baeck',49,'kayvonf@verizon.net','1969-11-24',1,8275),
('Shilo','Rabbinowitz',115,'duchamp@mac.com','1976-02-04',3,12144),
('Avimelech','Wassermann',9,'bsikdar@hotmail.com','1968-03-14',1,7215),
('Orian','Bamberger',257,'skythe@aol.com','1978-09-22',3,13787),
('Elijah','Susser',181,'gerlo@outlook.com','1975-12-04',3,12038),
('Amir','Balsam',122,'maneesh@sbcglobal.net','1972-11-13',2,10130),
('Senen','Manis',124,'sassen@live.com','1976-01-04',3,12091),
('Giannes','Kantor',17,'aibrahim@mac.com','1968-07-16',1,7427),
('Michaela','Smashnova',259,'plover@outlook.com','1978-10-23',3,13840),
('Mal','Bayme',139,'william@me.com','1973-09-19',3,10660),
('Jeremy','Janner',59,'danneng@hotmail.com','1968-04-14',1,8540),
('Jader','Bezalel',85,'juliano@yahoo.ca','1971-06-05',1,9229),
('Natali','Shub',231,'wortmanj@aol.com','1977-08-15',3,13098),
('Gavi','Rosenthal',47,'telbij@icloud.com','1969-10-24',1,8222),
('Dovev','Levi',161,'pmint@att.net','1974-08-26',3,11243),
('Ela','Matusevitch',265,'smeier@msn.com','1979-01-24',3,13999),
('Rinat','Zeiman',275,'jacks@comcast.net','1979-06-28',3,14264),
('Noy','Shafiner',351,'matty@outlook.com','1982-09-18',3,16278),
('Michal','Lerner',289,'rnelson@yahoo.ca','1980-01-31',3,14635),
('Chavatzelet','Wolf',227,'godeke@att.net','1977-06-14',3,12992),
('Naomi','Liberman',347,'keiji@yahoo.ca','1982-07-18',3,16172),
('Irit','Kedar',261,'bradl@gmail.com','1978-11-23',3,13893),
('Oshra','Rubin',295,'grinder@mac.com','1980-05-03',3,14794),
('Nimrod','Aronthal',167,'rain@ko@msn.com','1974-11-27',3,11402),
('Fanya','Cowen',369,'gfody@yahoo.com','1983-06-24',1,16755),
('Daniele','Gross',169,'mavilar@me.com','1974-12-28',3,11455),
('Yehoash','Levinson',23,'seano@comcast.net','1968-10-17',1,7586),
('Eden','Rocker',367,'mstrout@mac.com','1983-05-24',3,16702),
('Rina','Ophir',269,'drewf@icloud.com','1979-03-27',3,14105),
('Jori','Twersky',127,'dimensio@gmail.com','1973-03-17',2,10342),
('Yeshaya','Frankel',117,'airship@yahoo.com','1972-10-13',2,10077),
('Akub','Bloom',63,'maratb@sbcglobal.net','1970-06-29',1,8646),
('Uriel','Hart',51,'ideguy@aol.com','1969-12-25',1,8328),
('Shirli','Liberman',371,'jramio@me.com','1983-07-25',4,16808),
('Emuna','Ginsberg',303,'fwitness@yahoo.ca','1980-09-04',3,15006),
('Natanael','Luxemburg',133,'trygstad@hotmail.com','1973-06-18',2,10501),
('Rebecca','Backer',329,'satishr@yahoo.ca','1981-10-12',1,15695),
('Mika','Grunwald',255,'neonatus@yahoo.ca','1978-08-22',3,13734),
('Mathe','Goldman',35,'jacks@me.com','1969-04-21',1,7904),
('Yahel','Sarkin',209,'skythe@me.com','1976-09-08',3,12515),
('Michal','Goldschmidt',297,'harp@ko@outlook.com','1980-06-03',3,14847),
('Racheli','Barak',283,'dawnsong@comcast.net','1979-10-30',1,14476),
('Oranit','Trachtenberg',389,'geoffr@mac.com','1984-04-29',4,17285),
('Roni','Mowshowitch',319,'pthomsen@aol.com','1981-05-10',2,15430),
('Jussi','Mayer',121,'oster@yahoo.ca','1972-12-14',2,10183),
('Lilach','Shapiro',395,'jcholewa@live.com','1984-07-31',4,17444),
('Bracha','Sharett',267,'jtorkbob@live.com','1979-02-24',1,17052),
('Dasha','Duchan',361,'ubergeeb@hotmail.com','1983-02-20',1,16543),
('Chaim','Hodesmann',113,'bulletin@live.com','1972-08-12',2,9971),
('Cochava','Goldschmidt',317,'codex@comcast.net','1981-04-09',3,15377),
('Laban','Yedidyah',149,'epeeist@comcast.net','1974-02-21',3,10925),
('Amalia','Samuel',253,'aprakash@att.net','1978-07-22',2,13681),
('Arye','Smashnova',171,'bartak@sbcglobal.net','1975-01-28',3,11508),
('Zack','Lawson',3,'bmidd@me.com','1967-12-12',1,7056),
('Ronit','Ophir',233,'agapow@me.com','1977-09-15',3,13151),
('Ruma','Gottesman',237,'specprog@outlook.com','1977-11-16',3,13257),
('Adi','Zalkind',53,'ryanshaw@optonline.net','1970-01-25',1,8381),
('Makis','Novokovichi',177,'nichoj@gmail.com','1975-05-01',3,11667),
('Laban','Bruck',153,'satishr@yahoo.com','1974-04-24',3,11031),
('Ahuva','Jung',239,'speev@ko@yahoo.com','1977-12-17',2,13310),
('Habib','Lerner',163,'jacks@icloud.com','1974-09-26',2,11296),
('Chana','Malbim',243,'msroth@live.com','1978-02-17',3,16416),
('Mosheh','Loewe',27,'augusto@live.com','1968-12-18',1,19692),
('Akiva','Jung',55,'ivoibs@verizon.net','1970-02-25',1,8434),
('Evelyn','Rocker',91,'animats@hotmail.com','1971-09-06',2,19388),
('Orah','Hurwitz',311,'gilmoure@gmail.com','1981-01-06',2,15218),
('Yoav','Sayar',125,'sburke@yahoo.ca','1973-02-14',2,10289),
('Avigail','Adler',383,'jbuchana@gmail.com','1984-01-27',4,17126),
('Tamar','Aronthal',353,'dsowsy@mac.com','1982-10-19',3,16331),
('Moshe','Shiloh',183,'dogdude@mac.com','1975-08-02',3,11826),
('Yahel','Zeiman',263,'odlyz.ko@me.com','1978-12-24',3,13946),
('Inbar','Pomerantz',299,'bruck@verizon.net','1980-07-04',3,14900),
('Ruchama','Bach',211,'skajan@msn.com','1976-10-09',3,12568),
('Miriam','Demsky',377,'sekiya@outlook.com','1983-10-26',4,16967),
('Rachel','Marks',223,'froodian@aol.com','1977-04-13',3,12886),
('Aviel','Shimoni',159,'luebke@live.com','1974-07-26',3,11120),
('Dorit','Sarasohn',271,'boftx@att.net','1979-04-27',3,14158),
('Yael','Shub',309,'rogerspl@yahoo.ca','1980-12-06',3,15165),
('Giacomo','Kabotinsky',109,'fangorn@optonline.net','1972-06-11',2,19865),
('Asaph','Pick',87,'glenz@live.com','1971-07-06',2,9282),
('Nava','Kempinski',375,'mcnihil@optonline.net','1983-09-25',4,16914),
('Jeremie','Zoegell',21,'grossman@msn.com','1968-04-14',1,7480),
('Shoshi','Garbacz',349,'ajohnson@live.com','1982-08-18',2,16225),
('Lapidoth','Hurwitz',25,'dburrows@hotmail.com','1968-11-17',1,7639),
('Lavan','Wassermann',1,'itstatus@msn.com','1967-11-11',1,7003),
('Jonam','Shimshelewitz',145,'cmdrgravy@verizon.net','1973-12-21',3,10820),
('Zmira','Becker',399,'bonmots@verizon.net','1984-10-01',4,17550),
('Gabriel','Bruck',393,'nighthawk@me.com','1984-06-30',1,17391),
('Amir','Segal',77,'jyoliver@outlook.com','1971-02-01',1,19017),
('Joshua','Goldbloom',83,'brbarret@msn.com','1971-05-05',1,19176),
('Avner','Reiss',187,'ranasta@icloud.com','1975-10-03',3,12032),
('Rafi','Sieff',41,'iamcal@aol.com','1969-07-23',1,18063),
('Jehoichin','Sharansky',45,'wortmanj@live.com','1969-09-23',1,8169),
('Heber','Mannes',165,'osrin@verizon.net','1974-10-27',3,11349),
('Oshra','Beer',293,'papathan@comcast.net','1980-04-02',3,14741),
('Meirav','Sharot',241,'eegsa@live.com','1978-01-17',3,13363),
('Ofir','Pinero',215,'fatelk@gmail.com','1976-12-10',3,12674),
('Gal','Brenner',203,'eabrown@comcast.net','1976-06-07',3,12356),
('Ziva','Baum',363,'nighthawk@mac.com','1983-03-23',3,16596),
('Ravid','Goni',101,'osrin@outlook.com','1972-02-08',2,9653),
('Jamie','Litvinov',105,'dsugal@verizon.net','1972-04-10',2,9759),
('Inna','Somper',323,'muzzy@att.net','1981-07-11',3,15536),
('Sgula','Ran',229,'jdray@verizon.net','1977-07-15',3,13045),
('Dalit','Okin',285,'webinc@me.com','1979-11-30',3,14529),
('Avital','Lotner',359,'jbailie@live.com','1983-01-20',3,6490),
('Fruma','Emanuel',391,'corrada@comcast.net','1984-05-30',4,17338),
('Arie','Sklare',173,'wsnyder@sbcglobal.net','1975-02-28',3,11561),
('Nissim','Abramson',135,'bryanw@yahoo.ca','1973-07-19',2,10554),
('Chava','Shulman',291,'jbuchana@yahoo.com','1980-03-02',3,6688),
('Marina','Dresner',201,'calin@icloud.com','1976-05-07',3,12303),
('Ofra','Breuer',357,'bastian@outlook.com','1982-12-20',3,16437),
('Matityahu','Iskowitch',131,'sethbrown@aol.com','1973-05-18',2,10448),
('Abigail','Luxemburg',385,'wsnyder@optonline.net','1984-02-27',4,17179),
('Zared','Liberman',67,'roesch@optonline.net','1970-08-30',1,8752),
('Isaac','Wakstok',95,'singer@att.net','1971-11-07',2,9494),
('Eliezer','Heilbron',57,'duchamp@verizon.net','1970-03-28',1,8487),
('Shira','Mendel',273,'bwcarty@icloud.com','1979-05-28',3,14211),
('Einat','Spiegel',213,'iapetus@verizon.net','1976-11-09',3,12621),
('Schmuel','Cohen',137,'bancboy@sbcglobal.net','1973-08-19',3,10607),
('Noya','Shalit',341,'kobayasi@hotmail.com','1982-04-16',3,16013),
('Dovev','Gould',143,'sjava@@mac.com','1973-11-20',3,10766),
('Uri','Wolmark',287,'marcs@verizon.net','1976-03-06',3,12317),
('Yonni','Malbim',103,'aschmitz@optonline.net','1972-03-10',2,9706),
('Jered','Graetz',107,'temmink@gmail.com','1972-05-11',2,9812),
('Riki','Brenner',339,'kosact@mac.com','1982-03-16',3,15960),
('Sol','Woolf',39,'thomasj@outlook.com','1969-06-22',1,8010),
('Nili','Kabotinsky',277,'rgarton@live.com','1979-07-29',3,14317),
('Orah','Daiches',235,'lydia@aol.com','1977-10-16',3,13204),
('Dan','Helfgott',89,'eminence@outlook.com','1971-08-06',2,9335),
('Orli','Kalish',365,'frikazoyd@msn.com','1983-04-23',3,16649),
('Ian','Levine',189,'stevelim@sbcglobal.net','1975-11-03',3,12185),
('Shuki','Ascher',401,'csilvers@icloud.com','1975-07-02',3,11773),
('Riva','Shine',221,'staikos@live.com','1977-03-13',3,12833),
('Shmulik','Bayme',79,'jesse@att.net','1971-03-04',1,9070),
('Jeremi','Kantor',5,'houle@aol.com','1968-01-12',1,7109),
('Oded','Wigram',175,'yamla@live.com','1975-03-31',3,11614),
('Isabel','Maccoby',75,'zava@dsky@msn.com','1971-01-01',1,8964),
('Zachi','Halevi',65,'barlow@yahoo.ca','1970-07-30',1,8699),
('Noa','Munk',61,'rain@ko@hotmail.com','1970-05-29',1,8593),
('Orian','Gretz',333,'jrkorson@hotmail.com','1981-12-13',3,15801),
('Adina','Rothenstein',301,'spadkins@att.net','1980-08-04',3,14953),
('Zahava','Pick',315,'stellaau@optonline.net','1981-03-09',3,15324),
('Shuimon','Shub',71,'chance@me.com','1970-10-31',1,8858),
('Sonia','Sharansky',402,'eidac@att.net','1979-12-31',3,14582),
('Mirit','Zalkind',343,'zeller@outlook.com','1982-05-17',3,16066),
('Mikhail','Vinchevsky',15,'papathan@hotmail.com','1968-06-15',1,7374),
('Hadar','Reinharz',29,'gslondon@sbcglobal.net','1969-01-18',1,7745),
('Zahava','Metz',207,'goldberg@yahoo.com','1976-08-08',3,12462),
('Hodaya','Homa',335,'atmarks@optonline.net','1982-01-13',3,15854),
('Anna','Levitt',245,'muadip@verizon.net','1978-03-20',3,13469),
('Avishag','Chagall',155,'tattooman@verizon.net','1974-05-25',3,11084),
('Cheli','Sacher',387,'dwsauder@sbcglobal.net','1984-03-29',4,17232),
('Orah','Pollack',331,'smallpaul@verizon.net','1981-11-12',3,15748),
('Sara','Har-Zahav',313,'rohitm@msn.com','1981-02-06',3,17271),
('Jaffa','Emanuel',69,'skythe@att.net','1970-09-30',1,8805),
('Chaviv','Levy',31,'jandrese@mac.com','1969-02-18',1,7798),
('Meital','Fiedler',219,'mfburgo@me.com','1977-02-10',3,12780),
('Dikla','Beer',251,'kronvold@outlook.com','1978-06-21',2,13628),
('Josiah','Goulston',157,'frosal@aol.com','1974-06-25',3,11137),
('Yair','Zundel',281,'fairbank@aol.com','1979-09-29',3,14423),
('Levi','Kahn',179,'jyoliver@msn.com','1975-06-01',3,11720),
('Avi','Neumegen',13,'heckerman@yahoo.com','1968-05-15',1,7321),
('Liora','Mendenhall',397,'pakaste@comcast.net','1984-08-31',4,17497),
('Mali','Sternberg',99,'jimmichie@gmail.com','1972-01-08',2,9600),
('Eii','Schalit',21,'mhanoh@att.net','1968-09-16',1,7533),
('Tova','Rosenthal',111,'fraterk@me.com','1972-07-12',2,9918),
('Drora','Shahar',381,'kspiteri@yahoo.com','1983-12-27',4,17073),
('Ephraim','Angel',123,'epeeist@att.net','1973-01-14',2,10236),
('Yamit','Wirth',247,'wojciech@gmail.com','1978-04-20',1,13522),
('Eliyohu','Wolf',141,'jaarnial@mac.com','1973-10-20',1,10713),
('Matti','Duchan',134,'suresh@verizon.net','1976-04-06',3,12250),
('Nathanial','Endelman',116,'stern@yahoo.com','1972-09-12',2,10024),
('Miki','Sherman',217,'chaikin@aol.com','1977-01-10',3,12727),
('Zacharia','Sharot',43,'jaesenj@sbcglobal.net','1969-08-23',1,8116),
('Nitzanit','Hyamson',305,'pedwards@hotmail.com','1980-10-05',3,17059),
('Debbi','Itzik',7,'ninenine@att.net','1968-02-12',1,7162),
('Dorin','Spiro',379,'multiplx@icloud.com','1983-11-26',4,17020),
('Israela','Yoffey',355,'jcholewa@mac.com','1982-11-19',3,16384),
('Nimrod','Uki',151,'zeitlin@optonline.net','1974-03-24',3,10978),
('Tziona','Asher',373,'pthomsen@comcast.net','1983-08-25',2,16861),
('Benzion','Diamond',37,'seano@mac.com','1969-05-22',1,7957),
('Tzofia','Matusevitch',327,'treev@ko@gmail.com','1981-09-11',3,15642),
('Oded','Pekarsky',33,'fmtbebuck@live.com','1969-03-21',1,7851),
('Chagai','Landeshut',97,'nweaver@me.com','1971-12-08',2,9547),
('Yanis','Grossman',73,'schwaang@gmail.com','1970-12-01',1,8911),
('Yardena','Spiro',345,'geeber@comcast.net','1982-06-17',3,16119)
;

--1 הצג את כל נתונים 
select * from haovdim

-- הצג את כל הנתונים של כל העובדים, העובדים במחלקה 2
select * from haovdim where machlaka =  1

--3 הצג את כל  הנתונים של כל העובדים המשתכרים מעל 11000 שח העובדים 
--במחלקה 3
select * from haovdim where machlaka = 3 and maskoret >  11000

--4 הצג את כל  הנתונים של כל העובדים המשתכרים בין 10000 שח ל- 12000 שח
select * from haovdim where  maskoret between 10000 and 12000 

--5 הצג את כל  הנתונים של כל העובדים המשתכרים פחות מ - 10000  או יותר מ- 12000 שח
select * from haovdim where maskoret < 10000  or maskoret >12000 

--6	הצג אך ורק את השמות הפרטיים ואת האימיילים של כל העובדים
select prati,doal from haovdim

--7  gmail.com הצג את כל הנתונים של כל העובדים שיש להם מייל ב-
select * from haovdim where doal LIKE  '%gmail.com'

--8 הצג את כל הנתונים של כל העובדים, העובדים במחלקה 1, ממוינים לפי שם המשפחה
select * from haovdim where machlaka =  1 order by mishpacha

-- 9 הצג את כל הנתונים של כל העובדים, ממוינים לפי מחלקה בסדר יורד, עם מיון פנימי (לפי מחלקה) של השם הפרטי
select * from haovdim order by machlaka desc, prati

--10 הצג את כל הנתונים של שלושה העובדים בעלי המשכורות הגבוהה ביותר
select top 3 * from haovdim order by maskoret desc

--11 הצג את כל  הנתונים של כל העובדים המשתכרים מעל 19000 שח
select * from haovdim where maskoret > 19000 

--12 הצג רשימה של המחלקות של עובדים אלו 
--(השתמש ב- distinct)
select distinct machlaka from haovdim


--חלק ג
--1  oshra rubin תשנה את שם המשפחה של 
-- oshra cohen להיות 
update haovdim
set mishpacha = 'cohen'
where mishpacha = 'rubin'

--2  תציג את כל הפרטים עבור כל העובדים 
--שמשתכרים פחות מ- 7500 ₪. תעלה את שכרם בעשרה אחוזים
--כמה יש עכשיו 

update haovdim
set maskoret = maskoret * 1.1 
where maskoret < 7500

--3 תוסיף טור המתאר עבור כל עובד האם יקבל בונוס
--ברירת המחדל יהיה בונוס 0
alter table haovdim 
add bonus int

--4 תתן בונוס של 50 ₪ לכל העובדים של מחלקה 1
update haovdim 
set bonus = 50
where  machlaka = 1

--5 תמחק את הטור שהוספת
alter table haovdim drop column bonus

--6 מחק את כל הנתונים של כל העובדים עם תיק אישי מעל 390
delete from haovdim where tikishi > 390

--חלק ד
--1 תצרף מספר סידורי עם סדר רץ למסד הנתונים
-- (האם זה משנה שהוא רשום בסוף?)
alter table haovdim
add  id int identity(1,1) primary key,

--2 תבצע בקרה על המסד – המבטיחה שלא תהיינה משכורות מתחת ל- 8000 
--שח אם יש כאלה – תשנה את המשכורות הללו כדי שלא תהיינה מתחת לסכום 
--זה
update haovdim
set maskoret = 8000
where maskoret > 8000
 
alter table haovdim
add check (maskoret <= 8000)

insert into haovdim values
('Yardena','Spiro',345,'geeber@comcast.net','1982-06-17',3,16119)

--3 תבצע בקרה שאין אימיילים זהים ובדוק את זה
alter table haovdim
add unique(doal)

insert into haovdim values
('Yardena2','Spiro2',3452,'geeber@comcast.net','1982-06-17',3,161192)


---חלק ה
--לפני שנתחיל הקדמה 
--פקודת
-- זה פוקדה שסופרת כמה פעמים יש נתון מסויים count
--זה הסכום הכולל של המכירות וכדומה  sum 
-- זה פקודת המכירה הכי גדולה שהיה אי פעם בטבלה max 
-- זה פקודת חישוב ממוצע של מכירות avg
--זה פקודת חישוב המכירה הכי קטנה שיש בטבלה  min
--as אם לא נותנים שם אז לא צריך לכתוב 
-- היא לוקחת לפי קבוצות   group by 

--1 . רשום שאילתה הבודקת כמה עובדים יש במחלקה 3.
select count(machlaka)  from haovdim
where machlaka = 3

--2 רשום שאילתה הבודקת מה המשכורת הממוצעת של כל העובדים.
select avg(maskoret) from haovdim

--3 רשום שאילתה הבודקת כמה כסף החברה משלמת על מחלקה מספר 1 
select sum(maskoret) from haovdim
where machlaka = 1

--4 רשום שאילתה הבודקת מה המשכורת הנמוכה ביותר של העובדים עם תיק אישי בין 200 ל 300.
select min(maskoret) from haovdim
where tikishi between 200  and 300 

--5 רשום שאילתה הבודקת מה הממוצע של המשכורות לפי כל מחלקה.
select machlaka,avg(maskoret) from haovdim
group by machlaka

--6  תציב תוכן לפי המפתח הבא: עובדים  vetek תוסיף טור לטבלה בשם 
-- chadash מעל 300:  benoni בין 150 ל- 300: vatikim עם תיק אישי עד 150
-- ? כמה חדשים יש במחלקה 4
alter table haovdim
add vetek nvarchar(50)

update haovdim
set vetek = 'vatikim'
where tikishi <= 150

update haovdim
set vetek = 'benoni'
where tikishi  between 150  and 300 

update haovdim
set vetek = 'chadash'
where tikishi > 300

--chadash = חדש
--benoni = בנוני
--vatikim = וותיק

select count(prati) from haovdim
where machlaka = 4 and vetek = 'chadash'

--7 מהי המשכורת הגבוהה ביותר של העובדים בעלי וותק בינוני
select max(maskoret) from haovdim
where vetek = 'benoni'

--8 הצג את קבוצות הוותק בעלות משכורת ממוצעת של מעל 10000
select prati from haovdim
where vetek = 'vatikim'
group by prati
having avg(maskoret) > 10000  


---חלק ו 
--5.1.	תיצור (במסד הנתונים בו נמצאת טבלה העובדים הרגילה) טבלה 
--חדשה של מנהלי ארבעת המחלקות. 
--בטבלה יהיו הפרטים הבאים עבור כל מנהל-מחלקה: 
--•	מספר סידורי,
--•	שם פרטי,
--•	שם משפחה, 
--•	ומספר המחלקה אותה הוא/היא מנהל/ת. 
create table manager
(
id int identity(1,1) primary key,
prati nvarchar(30),
mishpacha nvarchar(30),
machlaka int
)

insert into manager values
('נתנאל','קדוש',2),
('לידור','אתדגי',3),
('ירון','מחשב',1),
('אריראל','היפני',4);

--2 תציג את שם המנהל/ת של העובד בעל המשכורת הגבוהה ביותר
select top 1 haovdim.maskoret, manager.prati from haovdim,manager 
order by haovdim.maskoret desc

--3 תציג שמותיהם של עובדים עם תיק אישי בין 50 ל- 200 עם שמותיהם של 
--מנהלי המחלקה שלהם.
select haovdim.prati,manager.prati from haovdim,manager 
where manager.machlaka = haovdim.machlaka and haovdim.tikishi  between 50  and 200 

--4 תיצור טבלה נוספת חדשה, המכילה נתונים של עובדים שלקחו הלוואה 
-- מהחברה. בטבלה הזו יהיו טורים: 
--•	מספר סידורי של הלוואה
--תוסיף לטבלה של העובדים מספר סידורים אם אין לו אל תשתמש בתיק אישי
--•	את סכום ההלוואה שהוא לקח. 
--הכנס לפחות עשר רשומות לטבלה. 
--
alter table haovdim
add  id int identity(1,1) primary key
 
create table loans
(
id int identity(1,1) primary key,
id_haovdim int, 
numberLoans int
)

insert into loans values
(20,3000),
(34,34343),
(78,33434),
(300,23232),
(42,33343),
(4,6000),
(10,8000),
(235,9000),
(298,10000),
(156,183000)


--5 תציג את שמות המנהלים להם יש עובדים עם חובות, ואת גובה ההלוואה של העובד.
select manager.prati,loans.numberLoans from
haovdim,manager,loans
where haovdim.id = loans.id_haovdim 

--6 שילוב פונקציות איסוף על איחוד טבלאות: כנ"ל בשאלה,5.4 אך יוצגו 
-- הספירה וסיכום של כל ההלוואות, לפי מנהל. (לדוגמא: למנהל משה יש 
-- חמישה עובדים שחייבים בסך הכל 13234 שח)
select manager.prati,sum(loans.numberLoans) from haovdim,manager,loans
where manager.machlaka = haovdim.machlaka
group by manager.prati

--חלק ז שלוש טבלות א
-----תיצור את הטבלות הבאות
------    א
--תיצור טבלה של לקוחות 
--בטבלה היו הפריטים הבאים
--מספר סידורי
--שם הלקוח עם בקרה שאי אפשר שלא היה ערך
-- unique אימייל עם בקרה של     
-- unique מספר טלפון עם בקרה של 
-- שהגיל לא יכול להיות מתחת ל 18 check גיל עם בקרה 
create table customers
(
id int identity(1,1) primary key,
name  nvarchar(30),
email nvarchar(30) unique,
phone int unique,
age int check(age >= 18)
)

insert into customers values
('נתנאל','fefOOL@gameil.com',0524343,19),('לידור','feretRr@gameil.com',052343423,24),
('מאיר','feYYed@gameil.com',505503,30),('מרב','etUUfOpe@gameil.com',4545453,26),
('אביל','feYYwwQWw@gameil.com',4504559,29),('אור','defeSSccXX@gameil.com',3485494,28),
('יורם','errtruuUUd@gameil.com',405054,21),('אייאל','TRreeww@gameil.com',67584,30),
('ישי','ghfjksS@gameil.com',382323,24),('שי','gnfmmmeAA@gameil.com',483903,23)


-------   ב
--תיצור טבלה של מוצרים 
--בטבלה היו הפריטים הבאים 
--מספר סידורי
--שם המוצר
--המכיר שלו
create table products(
id int identity(1,1) primary key,
name  nvarchar(30),
price int
)

insert into products values
('אופניים חשמליות',26),('שולחן מתקפל',30),('בצים',25),('חלבון',30),('סגריות',15),('אוזניות',40),
('לחם',10),('חלב',7),('בצים',25),('חלבון',30),('סגריות',15),('אוזניות',40),
('בשר',55),('לחם מלא',19),('קפה',12),('מטעון',16),('פוקימון',29),('מחשבון',14),
('מרק עוף',23),('קפה שחור',25),('מחברות',32),('כלי כתיה',5),('ספרי לימוד',30),('שקע חשמלי',35)

select * from products

---  ג
-- תיצור טבלה של מכירות 
-- בטבלה היו הפרטים הבאים
--מספר סידורי 
--מספר ספר מקושר של המוצר מהטבלה של המוצרים
--מספר מקושר של הלקוח מהטבלה של הלקוחות
-- מספר הכמות

create table buy(
id int identity(1,1) primary key,
Id_products int,
Id_customers int,
quantity int
)

select * from products

select * from customers

insert into buy values
(1,1,2),(2,1,3),(3,1,5),(4,1,10),(10,3,15),(5,2,10),(6,3,15),(12,3,15),
(3,6,4),(1,7,20),(1,10,12),(14,6,15),(18,6,1),(13,6,1),(12,6,1),(11,6,1),
(4,1,5),(5,4,23),(6,10,5),(7,6,9),(7,9,15),(8,8,10),(10,9,95),(1,6,15),
(19,1,2),(20,1,3),(10,1,5),(8,4,10),(10,3,15),(5,2,10),(6,3,15),(12,3,15),
(3,6,4),(1,7,20),(1,10,12),(14,6,15),(18,6,1),(13,6,1),(12,6,1),(11,6,1),
(4,1,5),(5,4,23),(6,10,5),(7,6,9),(7,9,15),(8,8,10),(10,9,95),(1,6,15)


-- 1 תראה לי את שם הלקוח שם הפריט הכמות ואת סכום המחירים של 
select customers.name, products.name,buy.quantity , sum(buy.quantity * products.price)as 'מחיר סופי' from products,customers,buy
where buy.Id_products = products.id and buy.Id_customers = customers.id group by customers.name,products.name,buy.quantity 

--2 תראה לי את המוצרים שקנת לקוח ראשון
select products.name,customers.name from products,customers,buy
where buy.Id_products = products.id and buy.Id_customers = customers.id and customers.id = 1

---3 תראה לי את הקניה הכי גדולה שהייתה אי פעם עם שם הלקוח 
select max(buy.quantity * products.price) as 'מחיר' from
products,customers,buy
where buy.Id_products = products.id and buy.Id_customers = customers.id 

--4 תספור את הכמות של הק יות של כל הלקוחות של נו
select customers.name,count(customers.id) as 'מחיר' from
products,customers,buy
where buy.Id_products = products.id and buy.Id_customers = customers.id group by customers.name

------------------------------------------------------------------------------
-- חלק ט
--בקרות על איחוד טבלות
drop table airports

--א
--תיצור טבלה של נמלי תעופה
--השדות היו כך
--מספר סידורי
--המיקום של הנמל
--כמות הכניסות שיש לנמל
create table airports(
id int identity(1,1) primary key,
position nvarchar(100),
numberOfHits int 
)
insert into airports values
('נמל התעופה הבו גוריון ישראל',4),('ארצות הברית אמסדרדם',30),('ארצות הברית אמסדרדם',30),
('ארצות הברית ניו יורק',34),('בריטניה לונדון',50)


--ב
--תיצור טבלה של חברת תעופה
--היו בה את השדות הבאים
-- מספר סידורי
--מספר סידורי של נמלי התעופה שמחובר ישירות אל הטבלה של נמלי התעופה שמחובר למספר הסידורי של הטבלה
--נמלי התעופה 
--מספר הנוסעים
--מספר עלות לכל לכרטיס
create table flights(
id int identity(1,1) primary key,
id_airpots  int foreign key references airports(id),
number_of_passengers int,
ticket_price int
)

insert into flights values
--השורה הזאת תעבוד
(2,34,46),(4,25,35),(3,35,48),(1,25,45),(5,34,75),
(1,40,20),(3,34,50),(4,45,65),(2,78,55),(5,44,55)
--השורה הזאת לא תעבוד
(6,30,45),(7,20,30),(0,30,45),(8,25,23),(9,35,75)

--א
--תראה לי את השתי הטבלות מאוחדות
select * from flights,airports 
where flights.id_airpots = airports.id

--ב
--תראה לי את הסכום שכל נמל תעופה הרוויח
--ואת המחיר הממוצע שכל אחד הרוויח
select airports.position,
avg(flights.number_of_passengers * flights.ticket_price)
as 'סכום ממוצע',
sum(flights.number_of_passengers * flights.ticket_price)
as 'סכום כולל'
from airports,flights
where flights.id = airports.id group by airports.position

--ג
--תראה לי את כל הנתונים שיש על נמל אחד
select * from
airports,flights
where airports.id = 1

--ד 
--תראה  לי את הכמות הכולל של הטיסות שהיו נמל תעופה מספר שתיים
select  airports.position,
count(flights.number_of_passengers * flights.t icket_price) as 'הסכום הכולל' 
from airports,flights
where airports.id = 2  group by airports.position
--1 
--------טבלה נופסת
create table mechirot 
( 
siduri int primary key identity(1,1) ,
shem nvarchar(50),
ezor nvarchar(50),
yom nvarchar(50),
mechiraYomit int
)
;


insert into mechirot values
('malka', 'zafon', '1', 2000), 
('malka', 'zafon', '2', 1000), 
('malka', 'zafon', '3', 1000),
('malka', 'zafon', '4', 2000),
('malka', 'merkaz', '5', 1000),

('liat', 'zafon', '1', 4000),
('liat', 'zafon', '2', 2000),
('liat', 'zafon', '3', 2000),
('liat', 'zafon', '4', 3000),
('liat', 'zafon', '5', 200),

('eden','merkaz', '1', 600),
('eden','merkaz', '2', 300),
('eden','merkaz', '3', 400),
('eden','merkaz', '4', 300),
('eden','merkaz', '5', 300)

create table managers
( 
siduri int primary key identity(1,1) ,
shem nvarchar(50),
machlaka int
)

insert into managers values
('rafi', 1),
('nofar', 4),
('tal', 3),
('amit', 2);


--1
--הצג את העובדים שהמשכורות שלהם מתחת לממוצע
select * from haovdim where maskoret < 
	(select avg(maskoret)from haovdim )
 --2
 --7.2.	הצג את כל עובדי המחלקה של בעל המשכורת הנמוכה ביותר
select * from haovdim where  machlaka = 
  (select top 1 machlaka  from haovdim order by maskoret)

--3
--7.3.	הצג את העובדים להם יש משכורת של 4000 ₪ (או יותר) מעל הממוצע של כל העובדים
select * from haovdim where maskoret >
 (select avg(maskoret) from haovdim) or maskoret > 4000 

 --4 
 select * from haovdim where  maskoret <
 (select avg(maskoret) from haovdim)

 --1
 -- תראה לי את המצורים שהמחיר שלהם מעל הממוצא 
 select * from  products where price > 
	(select avg(price) from products)

--2 תראה לי את הלקוחות שקנו מוצרים מעל הממוצאה של המחירים
select * from products,customers,buy
where buy.Id_products = products.id and buy.Id_customers = customers.id 
	and  price > (select avg(price) from products)

--3 תראה לי את את המוצרים שקנה נתנאל בלי כפילויות שמחיר מעל הממוצאה
select distinct products.name from products,customers,buy
where buy.Id_products = products.id and buy.Id_customers = customers.id  
	and price > (select  avg(price) from products ) and customers.name = 'נתנאל'

--4 7.8.	הצג את כל העובדים בעלי שם פרטי זהה כמו אחד מעובדי מחלקה מספר 
--(דהיינו: הצג את שני עובדים בעלי שם פרטי זהה, כאשר אחד מהם עובד במחלקה מספר 1, ואחד עובד במחלקה אחרת)
--in יש להשתמש ב
select * from haovdim where prati  
in
(select prati from haovdim where machlaka = 1 ) and  machlaka != 1

drop table Loans

create table Loans(
id int identity(1,1) primary key,-- מספר סידורי
tikishi int foreign key references haovdim(id),
sumNumber int check (sumNumber < 30000 )
)

select * from Loans
insert into Loans values
(1,6000),
(11,80),
(3,454),
(4,700),
(5,454),
(6,650),
(7,450),
(8,500),
(9,500),
(10,500),
(11,900),
(12,900),
(13,600);
--5
select * from manager 
where exists
(select * from Loans where sumNumber >= 600  )

--6
--drop table manager2 
create table manager2(
shem nvarchar(50),
machlaka int
)
select * from  manager2

insert into manager2 
	select distinct manager.prati,manager.machlaka from
	manager,haovdim
	where haovdim.machlaka = manager.machlaka and haovdim.maskoret <= 9000




	---פונקציות
--1
--פונקציה שמקבלת פטמטר שהוא סכום מסויים ובודוקת כמה עובדים מעל הסכום הזה 
create procedure checkPayroll @playroll int
as 
begin
select maskoret  from haovdim where maskoret > @playroll
end

exec checkPayroll @playroll = 12000
exec checkPayroll @playroll = 4000

---טבלה של מכירות

create table sikumhazmanot
(siduri int identity(1,1) primary key, 
yom date,
mocherid int, 
mechir float,
kamut int
);

-- =-=-=-=-=-=-=-=-=-=
insert into sikumhazmanot values
('01-02-1998', 1, 8.7, 13),
('01-02-1998', 2, 3.2, 85),
('01-02-1998', 2, 18.6, 6),
('01-02-1998', 2, 81.2, 27),
('01-03-1998', 1, 32.0, 82),
('01-03-1998', 2, 7.2, 85),
('01-03-1998', 1, 4.7, 49),
('01-04-1998', 1, 23.7, 52),
('02-04-1998', 1, 67.4, 52),
('02-04-1998', 2, 34.3, 16),
('02-05-1998', 2, 100.0, 1),
('02-05-1998', 3, 200.0, 5)
;

-- פונקציה שמקבל פרמטר משתנה שהוא הסכום שאותו אנחנו בדוקים האם עברנו אם כן 
-- אז מדפיסים טוב ואם לא עברנו אוטתו מדפיסים רע מאוד
create procedure sales @playroll int
as 
begin
declare @mechira int = (select sum(mechir*kamut) from sikumhazmanot)
if @mechira > @playroll
	begin
		select 'טוב'
	end
else 
	begin
		select 'רע מאוד'
	end
end

exec  sales @playroll = 50000

drop TABLE products
CREATE TABLE Products (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
    ProductName NVARCHAR(100) NOT NULL,
    SellerName NVARCHAR(100) NOT NULL,
    Sales INT NOT NULL,
    Price INT NOT NULL,
    SaleDate NVARCHAR(20) NOT NULL -- Adjust the size according to your date format
);

-- הכנסת 100 שורות נוספות לטבלת המוצרים עם שמות מוצרים אקראיים ושמות של אנשים כמוכרים
INSERT INTO Products VALUES
     ('מכונת קפה', 'דניאל כהן', 50, 200, 'יום ראשון'),
    ('שולחן רחב', 'שרה לוי', 30, 150, 'יום שני'),
    ('כורסא נוחה', 'אברהם כהן', 20, 120, 'יום שלישי'),
    ('ספה מודרנית', 'רבקה כהן', 40, 300, 'יום רביעי'),
    ('שולחן סלון', 'יעקב לוי', 25, 180, 'יום חמישי'),
    ('מיטת יחיד', 'רחל כהן', 35, 250, 'יום שישי'),
    ('שידת לילה', 'אהרון כהן', 15, 100, 'שבת'),
    ('מזרון אורטופדי', 'לאה כהן', 10, 300, 'יום ראשון'),
    ('מקרר גדול', 'יוסף לוי', 60, 800, 'יום שני'),
    ('תנור אפיה', 'מרים כהן', 45, 400, 'יום שלישי'),
    ('שולחן כתיבה', 'אביב לוי', 55, 220, 'יום רביעי'),
    ('מכונת כביסה', 'דנה כהן', 30, 400, 'יום שלישי'),
    ('תלת גגון', 'מאיר לוי', 10, 100, 'יום שבת'),
    ('שולחן פינת אוכל', 'רן כהן', 20, 300, 'יום חמישי'),
    ('כיריים גז', 'דניאל כהן', 30, 500, 'יום שלישי'),
    ('מכונת תפירה', 'שירה לוי', 40, 600, 'יום רביעי'),
    ('מקרן קול', 'אברהם כהן', 20, 250, 'יום חמישי'),
    ('ספסל פרקטי', 'רבקה כהן', 35, 175, 'יום שישי'),
    ('כיריים חשמל', 'יעקב לוי', 50, 700, 'יום ראשון'),
    ('פינת אוכל', 'רחל כהן', 25, 350, 'יום שני'),
    ('מדפים נוספים', 'אהרון כהן', 15, 90, 'יום שלישי'),
    ('כיסא בר', 'לאה כהן', 10, 120, 'יום רביעי'),
    ('שולחן מחשב', 'יוסף לוי', 30, 400, 'יום חמישי'),
    ('ספסל משרדי', 'מרים כהן', 40, 250, 'יום שישי'),
    ('עטים ומחזיקי עטים', 'אביב לוי', 20, 50, 'שבת'),
    ('תמונות מעוצבות', 'דנה כהן', 35, 180, 'יום ראשון'),
    ('מתקן תליה למגבות', 'שירה לוי', 25, 120, 'יום שני'),
    ('שולחן עגול', 'אברהם כהן', 45, 300, 'יום שלישי'),
    ('כסאות פלסטיק', 'רבקה כהן', 30, 70, 'יום רביעי'),
    ('מדפים מעוצבים', 'יעקב לוי', 20, 220, 'יום חמישי'),
    ('ספה פינתית', 'רחל כהן', 50, 400, 'יום שישי'),
  ('מחשב נייד', 'יוסי', 50, 800, 'יום שני'),
('סמארטפון', 'שירה', 120, 600, 'יום שלישי'),
('טאבלט', 'משה', 30, 300, 'יום רביעי'),
('אוזניות', 'שלומי', 80, 100, 'יום חמישי'),
('מצלמה', 'דניאל', 25, 500, 'יום שישי'),
('מדפסת', 'יעל', 40, 200, 'שבת'),
('מסך מחשב', 'אלון', 60, 400, 'יום ראשון'),
('מקלדת', 'אורית', 70, 50, 'יום שני'),
('עכבר', 'יוסף', 90, 20, 'יום שלישי'),
('דיסק קשיח חיצוני', 'רוני', 35, 120, 'יום רביעי'),
('כונן פלאש USB', 'ליאון', 110, 15, 'יום חמישי'),
('מפצל אלחוטי', 'רחל', 65, 80, 'יום שישי'),
('שעון חכם', 'מיכל', 55, 150, 'שבת'),
('גשם', 'אודליה', 75, 70, 'יום ראשון'),
('רמקול בלוטות', 'נתן', 85, 90, 'יום שני'),
('קונסולת משחקים', 'אביגיל', 45, 400, 'יום שלישי'),
('מטען נייד', 'טל', 95, 30, 'יום רביעי'),
('כיסא מחשב', 'רונה', 20, 200, 'יום חמישי'),
('מנורת שולחן', 'דוד', 110, 25, 'שישי'),
('שולחן משרדי', 'ליאת', 25, 300, 'שבת'),
('טלוויזיה', 'דנה', 30, 700, 'יום ראשון'),
('מערכת תיאטרון ביתית', 'ירון', 40, 1000, 'יום שני'),
('מקרר', 'רינת', 50, 800, 'יום שלישי'),
('מכונת כביסה', 'שמואל', 65, 600, 'יום רביעי'),
('תנור רדיו', 'אבישי', 75, 150, 'יום חמישי'),
('מכונת קפה', 'נטע', 85, 50, 'יום שישי'),
('בלנדר', 'מרים', 95, 40, 'שבת'),
('טוסטר', 'שלי', 105, 30, 'יום ראשון'),
('מעבד מזון', 'אורי', 115, 80, 'יום שני'),
('מטייל', 'עומרי', 125, 200, 'יום שלישי'),
('מטהר אוויר', 'שירלי', 135, 150, 'יום רביעי'),
('מאורר חשמלי', 'רפי', 145, 70, 'יום חמישי'),
('תנור חשמלי', 'אבירם', 155, 100, 'יום שישי'),
('מזגן', 'עדי', 165, 500, 'שבת'),
('מרטפים', 'אילן', 175, 80, 'יום ראשון'),
('מייבש אוויר', 'אלמוג', 185, 120, 'יום שני'),
('אופניים', 'אסף', 195, 300, 'יום שלישי'),
('אוהל', 'שירלי', 205, 150, 'יום רביעי'),
('שק שינה', 'רותם', 215, 100, 'יום חמישי'),
('תיק גב', 'טל', 225, 80, 'יום שישי'),
('מגפי טיולים', 'דינה', 235, 120, 'שבת'),
('מכשיר דיג', 'רועי', 245, 50, 'יום ראשון'),
('גרר בקמפינג', 'אריה', 255, 70, 'יום שני')
  --1
  --פונקציה שמקבל יום כמשתנה מדפיסה את כל הנתונים שהמחיר הוא מעל הממוצע
create procedure sales2 @myDate NVARCHAR(20)
as 
begin
declare @mechira int = (select avg(Sales*Price) from Products where SaleDate = @myDate)
select * from Products where Sales*Price >= @mechira and SaleDate = @myDate
end

exec  sales2 @myDate = 'יום ראשון'