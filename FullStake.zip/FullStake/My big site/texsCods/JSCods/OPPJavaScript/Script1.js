// var student1 = {
//  name:"נתנאל",
//  age : 19,
//  school:"מכלל אשקלון", 
//  education: ["בית הספר אורט ","Udemy","מכללת אשקלון"],
//  brother1:{
//     name: "רביטל",
//     age:19
//  },
//  brother2:{
//     name: "מאיר",
//     age:27
//  },
//  married:false
// };
        
// var student2 = {
// name:"לידור",
// age:24,
// school:"מכללת אשקלון",
// married:true
// };


// console.log(`${student1.brother1.name } + ${student1.brother1.age }`)
 
///--אובקייט דינמי
// var colors = {};
// colors.orange = {code:123};
// colors.black = {code:[4,5,6]}
// console.log(colors.orange.code);


// var blogPosts = [
//     {
//         title:'מזג האוויר',
//         countent: "היום זה היה יום גשום",
//         comments: [
//             {
//                 name : "אדיר",
//                 lastName:"כהן"
//             }
//         ]
//     },
//     {
//         title:'מלחמה',
//         countent:"נהרגו שלושה מחבלים בעזה על ידי תקיפה של חייל האוויר"
//     }
// ];

// console.log(blogPosts)

// for(var i=0;i <blogPosts.length;i++){
//     console.log(blogPosts[i].title)
//     console.log(blogPosts[i].countent)
// }

var universites = [
    {
        name:"מכללת אשקלון",
        numberStudents: 70000,
        year: 2024
    },
   {
    name: "מכללת ספיר",
    numberStudents:100000,
    year: 2024
    }

];

console.log(universites)