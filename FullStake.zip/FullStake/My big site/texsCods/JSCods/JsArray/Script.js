//const numbers = [1,2,3,4,5,6,7,8,9,10];//<- מערך של מספרים
 
//const squares =  numbers.map(square);
//console.log(square);

//function square(element){
    //return Math.pow(element,2);
//}
/////////////////////-----------------------------------------------------------------------------------------

////---------------
////שיטות סינון
////---------
var numbers2 = [1,2,3,4,5,6,7,8,9,10];
var numbers3 = [10,20,30,40,50,60,70,80,90,100];
var evebNumbers = numbers2.filter(isEven);
var noEvenNumbrs = numbers2.filter(noEven);
var UpNumbar50 = numbers3.filter(numberUP50);

console.log(evebNumbers);
console.log(noEvenNumbrs);
console.log(UpNumbar50);

//מספר זוגי
function isEven(element){
    return element % 2 == 0;
}

//  מספר לא זוגי
function noEven(element){
    return element % 2!= 0;
}

// מספר שגדול מ50
function numberUP50(element){
        return element > 50;
}