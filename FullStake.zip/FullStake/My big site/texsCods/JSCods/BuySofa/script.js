var price = 0;
var priecproduct = 18500; 
var count = 0;
var Run = true
var InputPrice = document.getElementById("InputPrice");
var TexTPrice = document.getElementById("TexTPrice");
var TextMonths = document.getElementById("TextMonths");
console.log("is")

document.getElementById("goButton").onclick = function(){
    price = InputPrice.value;

        while(true){
            priecproduct -= price 
            count++      
            if( priecproduct <= price){
                break;
            }
        }
        console.log("is")
        TexTPrice.textContent = `${priecproduct} המחיר האחרון של החודש הוא `
        TextMonths.textContent = `${count} מספר החודשים שאתה צריך לשלם הוא  `


}



    

