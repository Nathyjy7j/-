
let count = 0;



document.getElementById("submit").onclick = function(){
    let MaxNumber = document.getElementById("MaxNUmber").value;
    let MinNumber = document.getElementById("MinNumber").value;
    let userName = document.getElementById("userNumber").value;
    

    count = Number(count);
    userName = Number(userName);
    
    let rundonNumber = Math.floor(Math.random() * (MaxNumber - MinNumber));

    if(userName == rundonNumber){

        count++
        document.getElementById("result").textContent = `תשובה נכונה מספר הניחושים הוא ${count} והמספר הרדנומלי הוא ${rundonNumber}`;
    }
    else{
        document.getElementById("result").textContent = `תשובה לא נכונה התוצא היא ${rundonNumber}`;
    }
}
