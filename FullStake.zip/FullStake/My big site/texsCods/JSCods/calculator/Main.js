

//------------------------------------
//כפל  
//--------------------------------------
function Mat1(){
    const num1 = document.getElementById("num1").value;
    const num2 = document.getElementById("num2").value;
    var numK = num1 * num2; 
    printS(numK);
}


//------------------------------------
//חיסור
//--------------------------------------
function Mat2(){
    const num1 = document.getElementById("num1").value;
    const num2 = document.getElementById("num2").value;
    var numK = num1 - num2;
    printS(numK);
}


//------------------------------------
//חילוק
//--------------------------------------
function Mat3(){
    const num1 = document.getElementById("num1").value;
    const num2 = document.getElementById("num2").value;
    var numK = num1 / num2;
    printS(numK);
}


//------------------------------------
//חיבור
//--------------------------------------
function Mat4(){
    var num1 = document.getElementById("num1").value;
   var num2 = document.getElementById("num2").value;
   num1 = Number(num1);
   num2 = Number(num2);
    var numK = num1 + num2;
    printS(numK); 
}

//------------------------------------
//מודולו
//--------------------------------------
function Mat5(){
    const num1 = document.getElementById("num1").value;
    const num2 = document.getElementById("num2").value;
    var numK = num1 % num2;  
    printS(numK);
}


//------------------------------------------------------------------
//רנדומלי
//------------------------------------------------------------------------------
function Mat6(){

    const value1 = Math.floor(Math.random() * 10000000);
    const value2 = Math.floor(Math.random() * 10000000);
   
    var num1 = document.getElementById("num1");
    var num2 = document.getElementById("num2");
    
   num1.value = value1
   num2.value = value2
}

//------------------------------------
//חזקה
//--------------------------------------
function Mat7() {
    var num1 = document.getElementById("num1").value;
    var num2 = document.getElementById("num2").value;
    const result = document.getElementById("result");
    num2 = Number(num2);
    num1 = Number(num1);
    var copy = num1;
    num1 =  Math.pow(num1, num2);
   
    printS(num1);
    
}


function printS(num){
    const result = document.getElementById("result");
    result.textContent = `התוצאה היא ${num}`;  
}





