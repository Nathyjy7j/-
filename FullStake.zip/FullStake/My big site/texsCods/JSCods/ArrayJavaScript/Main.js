function combineStrings(...strings){
    return strings.join(' ')
}

const fullName = combineStrings("נתנאל","מורדכי","קדוש")

console.log(fullName)