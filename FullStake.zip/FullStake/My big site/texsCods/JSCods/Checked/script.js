
const subscribe = document.getElementById("subscribe");
const text = document.getElementById("text");
const text2 = document.getElementById("text2");

const masterCar = document.getElementById("masterCar");
const payPal = document.getElementById("payPal");
const Visa = document.getElementById("Visa");


document.getElementById("submit").onclick = function(){

    if(subscribe.checked){
        text.textContent = "אתה מנוי";
    }
    else{
        text.textContent = "אתה לא מנוי";
    }

    if(masterCar.checked){
        text2.textContent = "אתה משלם במסטר כרטיס";
    }
    if(payPal.checked){
        text2.textContent = "אתה משלם בפילל";
    }
    if(Visa.checked){
        text2.textContent = "אתה משלם בויזה";
    }
}