let number = 0;
document.getElementById("num").textContent = number;

document.getElementById("down").onclick = function(){
    number--;
    document.getElementById("num").textContent = number;
}

document.getElementById("Rise").onclick = function(){
    number++;
    document.getElementById("num").textContent = number;
}

document.getElementById("zero").onclick = function(){
    number = 0;
    document.getElementById("num").textContent = number;
}