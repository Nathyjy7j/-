function creat(){
    const numButton  =  document.getElementById("numButton").value;
    const numInput =  document.getElementById("numInput").value;
    var container = document.getElementById("container");
    container.innerHTML = "";
    for(var i=0;i<numButton;i++){
        container.innerHTML += ` <button>${i}</button>
        <br>`
    }
    for(var i=0;i<numInput;i++){
        container.innerHTML += ` <input type="text">
        <br>`
    }


}