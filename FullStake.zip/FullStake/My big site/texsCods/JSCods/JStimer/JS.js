//--------------------------
//פונקציה של טמייר
///-------------------------------------
function Jstimer(){
    var text = document.getElementById("text");
    setTimeout(function () {
        text.textContent = "Hello";
    },2000);
}