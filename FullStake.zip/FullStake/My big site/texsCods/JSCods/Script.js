var number = 1
            function printNumber(){
                console.log(number)
                number++
            }