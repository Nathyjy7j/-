///תנאים
// בודק את הציון
// var grade;
// grade = 65;

// if(grade< 55){
//     console.log("אתה לא יכול להמשיך לכיתה הבא ")
// }
// else if(grade >= 55 && grade <= 60){
//     console.log("אתה עברת אבל עם ציון קטן")
// }
// else{
//     console.log("אתה עברת עם ציון טוב ")
// }

// בודק את הגיל
// var age = 24
     
// if(age < 18){
//     console.log("אתה צעיר מכדי להיכנס למקום")
// }
// else if(age <= 23){
//     console.log("אתה יכול להכינס אבל אסור לך לקנות ירוק")
// }else{
//     console.log("אתה יכול להכינס")
// }


// מתג 
//HTML
/* <input id="pounds" type="number" value="0">
<label for="pounds">כמה  קילוגרם אתה רוצה</label>
    <br>
<input id="Number"  type="number" min="1" max="3">
<label for="Number">איזה לחם אתה רוצה 1 עולה 10 שקל 2 עולה 40 שקל 3 עולה 15</label>   
<br>
<button onclick="by()">קנה</button>
<br>
 <label id="textEnd"></label>


function by(){
    var price = 0;
    var pounds = document.getElementById("pounds").value;
    var switchNumber = document.getElementById("Number").value;
    var textEnd = document.getElementById("textEnd");
    switchNumber = Number(switchNumber) 
    pounds = Number(pounds) 
   
    switch(switchNumber){
        case 1:
            price = pounds * 10;
            break;
        case 2:
            price = pounds * 40;
            break;
        case 3:
            price = pounds * 15;
            break;
        default:
            textEnd.textConten = "אין כלום"     
    }
    textEnd.textContent = `המכיר הסופי הוא ${price}`

} *////////////////////////////////////////////////////////////////}

// var age = 18

// switch(true){
//     case (age <=18 && age >0):
//         console.log("אתה צעיר מכדי להכינס ");
//         break;
//     case (age <30 ):
//         console.log("אתה יכול להכינס אבל בלי לקנות ירוק");
//         break;
//     case (age <= 120):
//             console.log("אתה יכול להכינס ללא הגבלות");
//             break;
//     default:
//         console.log("הגיל שהוזן לא נכון")        
//         break;
// }

// while(true){
//     var number = parseInt(prompt("כתוב מספר זוגי"))
//     if(number % 2 ==0){
//         document.write("המספר הוא זוגי")
//         break
//     }
    
// }

// while(true){
//     var number = parseInt(prompt("כתוב מספר לא זוגי"))
//     if(number % 2 !=0){
//         document.write("המספר הוא לא זוגי")
//         break
//     }
// }

// function print(text){
//     document.write(text + "<br>")
// }

// print("שלום נתנאל")
// print("היום יום חמישי")


function printArray(array){
    for(var i=0; i<array.length;i++){ 
        document.write(array[i] + "|")
    }
    document.write("<br>")
}


////מערכים
var students = ["נתנאל","לידור","אריאל"];
// printArray(students)
//היא מוסיפה למערך עוד אבר או אברים במיקום שאחרי האינדקס המקורי push מתודה
students.push("דניאל","ירון")
// printArray(students)

//היא מסירה את האבר האחרו במערך pop  מתודה
// printArray(students)
// students.pop();
// printArray(students)
// //שומר את הערך שבאינדקס האחרון במשתנה
// var nameRemoveStudent = students.pop();
// document.write(nameRemoveStudent)

// היא מוסיפה אבר למערך במיקום הראשון  unshift מתודה
students.unshift("סהר");
// printArray(students)

// היא מסירה את האבר הראשון ממערך shifr מתודה
// students.shift();
// printArray(students)

//היא מחזירה את המיקום בערך של המשתנה  indexOf מתודה
//אם האבר לא קיים אז הוא מחזיר מינוס אחד
// var student1 = students.indexOf("לידר")
// document.write(student1)
 

//היא פועלת לפי גודל המערך  forEach מתודה
// var books = ["ארי פוטר","שר הטבועות","משחקי הכאס","משחקי הערב"]

// books.forEach(function (book) {
//     document.write(book+ "|")
// });

// var numbers = []

// for(var i = 0 ;i<= 20;i++){
//     numbers.push(i);
// }
// printArray(numbers)
// //תדפיס את המספרים שהם קפצים במחמש כגון 5 10 15 20 
// numbers.forEach(function (number){
//     if(number % 5 == 0){
//         document.write(number + "|")
//     }
// })


                        // אובייקטים

function print(text){
    document.write(text + "|")
}
// var student1 = {
//     name: "נתנאל",
//     age:19,
//     school:"מכללת אשקלון"
// }
// var student2 = {
//     name:"לידור",
//     age:24,
//     school: "מכללת אשקלון"
// }

// print(student1.name)
// print(student1.age)
// print(student1.school)
// print("<br>")
// print(student2.name)
// print(student2.age)
// print(student2.school)

// var Netanel = {
//     name :"נתנאל",
//     familName:"קדוש",
//     age:19,
//     country: "ישראל",
//     city: "אשקלון"
// };

// var Lidor = {
//     name :"לידור",
//     familName:"אתדגי",
//     age:24,
//     country: "ישראל",
//     city: "אשקלון"
// };


// var students = {
//     student1: Netanel,
//     student2: Lidor
// }
// print(students.student1.familName)
// print(students.student2.familName)

// var student1 = {
//  name:"נתנאל",
//  age : 19,
//  school:"מכלל אשקלון", 
//  education: ["בית הספר אורט ","Udemy","מכללת אשקלון"],
//  brother1:{
//     name: "רביטל",
//     age:19
//  },
//  brother2:{
//     name: "מאיר",
//     age:27
//  },
//  married:false
// };
        
// var student2 = {
// name:"לידור",
// age:24,
// school:"מכללת אשקלון",
// married:true

// };


// console.log(`${student1.brother1.name } + ${student1.brother1.age }`)
 
///--אובקייט דינמי
// var colors = {};
// colors.orange = {code:123};
// colors.black = {code:[4,5,6]}
// console.log(colors.orange.code);


// var blogPosts = [
//     {
//         title:'מזג האוויר',
//         countent: "היום זה היה יום גשום",
//         comments: [
//             {
//                 name : "אדיר",
//                 lastName:"כהן"
//             }
//         ]
//     },
//     {
//         title:'מלחמה',
//         countent:"נהרגו שלושה מחבלים בעזה על ידי תקיפה של חייל האוויר"
//     }
// ];

// console.log(blogPosts)

// for(var i=0;i <blogPosts.length;i++){
//     console.log(blogPosts[i].title)
//     console.log(blogPosts[i].countent)
// }

// var universites = [
//     {
//         name:"מכללת אשקלון",
//         numberStudents: 70000,
//         year: 2024
//     },
//    {
//     name: "מכללת ספיר",
//     numberStudents:100000,
//     year: 2024
//     }

// ];

// console.log(universites)



// //להוסיף אברים לאובייקט
// var colors = {};

// colors.orange = {code: 123}
// print(colors.orange.code)



///------------------------------------------------ אתר לכתיבת תוכן
// <label>כתוב פוסט נוסף</label>
// <br>
// <input id = "titleInout">
// <label for="titleInout">כתוב כותרת</label>
//  <br>
//  <label for="contentInput">כתוב תוכן</label>
//  <br>
//   <textarea id="contentInput"></textarea>
  

//   <br>
//   <button onclick="InputUser()">שלח </button>
//    <br>
//    <button onclick="showPosts()">הצג</button>  
//   <div id="count">
     
//   </div>


// var blogPosts = [
//     {
//         title: "מזג האוויר",
//         content: "היום זה יום גשום"
//     }
// ]

// function InputUser(){

//    var  titleInout = document.getElementById("titleInout").value;
//     var contentInput = document.getElementById("contentInput").value;

//     var Post = {
//         title: titleInout,
//         content: contentInput
//     }
//     blogPosts.push(Post)
   
// }

// function showPosts(){
//     var count = document.getElementById("count")
//     count.innerHTML = ""
//     for(var i = 0 ;i < blogPosts.length;i++){
//         count.innerHTML += `פוסט  מספר ${i+1}` + "<br>" +  blogPosts[i].title + "<br>" + blogPosts[i].content +  "<br>"
//     }

// }
//----------------------------------------------------------------------------------------------------

//מתודות של אובייקטים
// var functions = {
//     print: function(text){
//         document.write(text)
//     },
//     printArray: function(array){
//         for(var i = 0;i < array.length;i++){
//             array[i] = i
//             var Mytext = array[i] + "|"
//             functions.print(Mytext)
//         }
//     },
//     creatArray: function(size){
//         var array = new Array(size)
//         return array
//     }
// }

// functions.print("שלום")
// var array = functions.creatArray(5)
// functions.printArray(array)



