///תוכנית שמחליפה צבע לפי מה שקבענו
// //צובע אלמנט מסויים בצבע שבחרנו
// var h2Element = document.querySelector('h2');
// h2Element.style.color = 'red'
////----------------------------
// תוכנית שמחליפה צבעים לי פונקציה וזמן
// var isYellow = false
// function  switchColor(){
//     if(isYellow){
//         h2Element.style.color = 'red'
//     }else{
//         h2Element.style.color = 'grey'
//     }
//     isYellow = !isYellow
// }

// // פונקציה מובנת שמה שהיא עושה לזה לקחת פרמטר של פונקצייה ופרמטר של משתנה של זמן 
// // ואחרי שהזמן עובר היא מפעל את הפונקציה ואז מחכה לפי הזמן ואז מפיעל את הפונקציה עוד הפעם
// setInterval(switchColor,1000);

//השיטות לקבל אלמנטים 
//  h1 אחד לפי שם האלמנט כמו 
// var h2Element = document.querySelector('h2');

// שזה שם מזה מיוחד לאותה תגיית id שתים לפי  
// <label id = "Text">בנננה ועוד בננה שווה שתי בנוות</label>
// var Text = document.getElementById("Text")// idחשוב מאוד שהשם שאנחנו נותנים לפונקציה הוא היה השם של ה
// console.log(Text)


// שלוש לפי שם של כיתה 
{/* <label class="MyText">tttt</label>
<label class="MyText">rrr</label>
<label class="MyText">tteeeett</label>
<label class="MyText">ttteewwwt</label> */}
// var MyText = document.getElementsByClassName("MyText")
// console.log(MyText)

// רבע לפי שם התג שלו
{/* <h1>שלום עולם</h1> */}
// var h2getElement = document.getElementsByTagName("h1")
// console.log(h2getElement)



