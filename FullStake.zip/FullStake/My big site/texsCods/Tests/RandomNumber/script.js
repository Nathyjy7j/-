let MaxNumber = 0;
let MinNumber = 0;
let NumberRandom = 0;

document.getElementById("submit").onclick = function(){
    MaxNumber = document.getElementById("MaxNUmber").value;
    MinNumber = document.getElementById("MinNumber").value;
    NumberRandom = Math.floor(Math.random() *  (MaxNumber - MinNumber));
    
    document.getElementById("NumberRandom").textContent =  "this Number "+NumberRandom;

}