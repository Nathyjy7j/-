
const NameUser = document.getElementById("NameUser");
const CyitUser = document.getElementById("CyitUser");
const FoodLiv = document.getElementById("FoodLiv");
const FamilyName = document.getElementById("FamilyName");


const schnitzel = document.getElementById("schnitzel");
const  mature = document.getElementById("mature");
const fish = document.getElementById("fish");


document.getElementById("Mybutton").onclick = function(){

    let InputName = document.getElementById("InputName").value;
    let InputCyit = document.getElementById("InputCyit").value;
    let InputFamilyName = document.getElementById("InputFamilyName").value;

    NameUser.textContent = "Name is " + InputName;
    CyitUser.textContent = "Cyit is " + InputCyit;
    FamilyNameUser.textContent = "Family Name is " + InputFamilyName; 

    if(schnitzel.checked){
        FoodLiv.textContent = "Food is " + "שניצל";
    }
    if(mature.checked){
        FoodLiv.textContent = "Food is " + "המבוגר";
    }
    if(fish.checked){
        FoodLiv.textContent = "Food is " + "דג";
    }

}


function changeBackground(color){
    document.querySelector('body').style.backgroundColor = color;
}

var input = document.getElementById('color');
var button = document.querySelector('button');

button.addEventListener('click', function( event ) {
   event.preventDefault();    
   var color = input.value;
   document.body.style.background = color;
});