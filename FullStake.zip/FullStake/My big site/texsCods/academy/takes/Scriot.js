
function upText(){
    var text = document.getElementById("text").value
    var endText = text.toUpperCase();
    console.log(endText)
    document.getElementById("myEndText").value =  endText
}



function  cke1(){

    var mytext = document.getElementById("is1").value
    if(mytext.includes(" ")){
        document.getElementById("myText3333").innerHTML = ""
    }else{
        document.getElementById("myText3333").innerHTML =  "בקקשה כתוב רויח"
    }
   
}


function  cke2(){
    var mytext = document.getElementById("is2").value
    if(mytext.includes("@")){
        document.getElementById("OPP").innerHTML = ""
    }else{
        document.getElementById("OPP").innerHTML =  "@ בבקשה כתוב "
    }

}