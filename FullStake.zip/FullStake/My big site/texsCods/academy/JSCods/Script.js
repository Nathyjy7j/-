function switchscript(){
    document.getElementById("swin").src = "Text.js"
}