
function whowImg(myImg,count){
   var str = ""
    document.getElementById("root").innerHTML = `<img src="${myImg.src}" >`
    switch(count){
        case 1:
            str ="מישהו מפעיל את התוכנית בלי הדפסה"
            break
        case 2 :
                str = "Java לפני השיעור של "
            break
        case 3:
            str = "קוד בעל 450 שורות"
            break
        case 4:
            str = "כשהמטבלה היא לעשות טבלת מעקב"    
            break
        case 5:
            str =  "error כשכל הקוד הוא"  
            break
        case 6:
            str =   "מתכנתים" 
            break
        case 7:
            str = "כשנופל לך האסימון שהבעיה היא מילה שמורה "    
            break

    }
    document.getElementById("text").innerHTML = str

}