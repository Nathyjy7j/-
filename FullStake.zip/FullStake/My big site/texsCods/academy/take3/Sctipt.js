
var one =1;
var zero = 0;
var sum = 0
var count =0 
function strts(){

    document.getElementById("outt").innerHTML = ""
    var userInpiutt = Number(document.getElementById("userInpiutt").value)

    for(var i=0;i< userInpiutt;i++){
        one=one+zero;
        zero=one-zero;
        sum+=zero
        count++
        document.getElementById("outt").innerHTML += zero +  "|"
       
    }
}


