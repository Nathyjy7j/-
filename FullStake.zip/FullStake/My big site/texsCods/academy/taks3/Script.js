function gerInput(){
    var num = Number(document.getElementById("number").value);

    for(var i=1;i<num;i++){
        if(i == 1){
            print(1)
            print(1)
        }else{
            var copy = i++;
            print(copy + i)
        }

    }

}


function printt(myVar){
    console.log(myVar)
    document.getElementById("myText").innerHTML +=myVar;
}