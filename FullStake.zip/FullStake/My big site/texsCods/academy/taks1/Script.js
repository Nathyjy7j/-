document.getElementById("root").style = "text-align: center; font-size: 40px;"

function check(){
    var is_op = false;
    var is_signature = false;
    var userInput1 =document.getElementById("op1").value;
    var userInput2 = document.getElementById("op2").value;
    var userInput3 = document.getElementById("op3").value;
    var signature = document.getElementById("signature").value;
    if(userInput1 !=""){
        if(userInput2 != "" || userInput3 !=""){
            is_op = true
        }
    }
  if(userInput2 != "" && userInput3 !=""){
        is_op = true
    }

    if(signature !=""){
        is_signature =true
    }

    if(is_signature && is_op){
        print("מצויין")
        if(document.getElementById("Z").checked){
            console.log("yes")
           document.getElementById("data").innerHTML = `
            ${userInput1} :הגיל שלך הוא 
            <br>
          ${userInput2}  : שם העיר שלך היא  
          <br>
         ${userInput3}   :המשהו שכתבה הוא 
         <br>
         ${signature} :החתימה שלך היא  `     
        }
    }else if(is_op && !is_signature){
        print("תחתום בבקשה יעצלן")
    }else if(!is_op && is_signature){
        print("בבקשה תענה על השאלות")
    }else{
        print("צריך לענות לפתות על שתי שאלות ולחתום")
    }   
}

function print(str){
    document.getElementById("res").innerHTML = str;
}


