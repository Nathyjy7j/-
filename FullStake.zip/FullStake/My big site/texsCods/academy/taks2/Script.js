var count = 0;
function getInput(num){
    num = Number(num)
    if(count == 0){
        if(num == 1){
            print("אני")    
            clerRorr()
            count++;
        }
        else{
            rorr()
        }
    }
    else if(count == 1){
     
        if(num == 2){
            print("רוצה")    
            clerRorr()
            count++;
        }else{
            rorr()
        }
    
    }
   else if(count == 2){
        if(num == 3){
            print("הביתה")    
            clerRorr()
            count++;
        }else{
            rorr()
        }
    }
    else if(count == 2){
        if(num == 3){
            print("הביתה")    
            clerRorr()
            count++;
        }else{
            rorr()
        }
    }
   else if(count == 3){
        if(num == 4){
            print("חצילו")    
            clerRorr()
            count++;
        }else{
            rorr()
        }
    }
     else  if(count == 4){
        if(num == 5){
            print("הצילו")    
            clerRorr()
            count++;
        }else{
            rorr()
        }
    }
}

function clerRorr(){
    document.getElementById("rorr").innerHTML = ""
}

function rorr(){
    document.getElementById("rorr").innerHTML = "שגיאה"
}

function print(str){
    document.getElementById("text").innerHTML += str + " "

}