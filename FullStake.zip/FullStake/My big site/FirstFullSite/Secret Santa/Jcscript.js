var ArrayParticipants  = new Array(0)
var bigs = new Array(0)
var dwarf = new Array(0)
var countInpunt = 0

function strt(){
    var numberParticipants = document.getElementById("numberParticipants").value;
    var Participants = Number(numberParticipants);
    if(Participants % 2 == 0){
        ArrayParticipants = creatArray(Participants)
        bigs = creatArray(Participants/2)
        dwarf = creatArray(Participants/2)
        console.log(ArrayParticipants)
    }else{
        print("יש שגיאה במספר המשתתפים")
    }
}

function creatArray(size){
    var array = new Array(size)
    return array;
}

function addNames(){
    if(countInpunt >= ArrayParticipants.length){
        body()
    }else{
        for(var i = 0;i<ArrayParticipants.length;i++){
            if(i == countInpunt){
                ArrayParticipants[i] = getName()
            }
        }
        countInpunt++;
        if(countInpunt >= ArrayParticipants.length){
            body()
        }
    }   
}

function print(text){
    var TexT = document.getElementById("TexT")
    TexT.innerHTML = text
}

function getName(){
    namePas = document.getElementById("namePas").value;
    return namePas
}


function body(){
    var lengthPa = ArrayParticipants.length
    var arrayArndom = new Array(lengthPa)

    for(var i = 0;i< arrayArndom.length;i++){
        var numberRndom = Math.floor(Math.random() * lengthPa )
        arrayArndom[i] = Math.floor(Math.random() * lengthPa )
    }
    arrayArndom = removeDup(arrayArndom)

    while(arrayArndom.length  < lengthPa){
     var numberRndom = Math.floor(Math.random() * lengthPa)

        arrayArndom.push(numberRndom)
        var numberRndom = Math.floor(Math.random() * lengthPa)
        arrayArndom.push(numberRndom)
        arrayArndom = removeDup(arrayArndom)
        if(arrayArndom.length > lengthPa){
        break
        }
    }

    for(var i = 0;i< bigs.length;i++){
        bigs[i] = ArrayParticipants[arrayArndom[i]]
    }
    
    var potisoit = lengthPa
    for(var i = 0;i< dwarf.length;i++){
        dwarf[i] = ArrayParticipants[arrayArndom[potisoit - 1]]
        potisoit--
    }
    var Gig = document.getElementById("Gig")
    var Dwarf = document.getElementById("Dwarf")

    var text1 = "הענקים" + "<br>"
    var text2 = "הגמדים" + "<br>"
    for(var i = 0;i<bigs.length;i++){
        text1 += bigs[i] + "|"
    }
    for(var i = 0;i<dwarf.length;i++){
        text2 += dwarf[i] + "|"
    }

    Gig.innerHTML = text1
    Dwarf.innerHTML = text2
}

function removeDup(array){
    var count = 0;
    for (var i = 0; i < array.length; i++) {
        for (var j = i + 1; j < array.length; j++) {
            if(array[i]==array[j]){
                count++;
                break;
            }
        }
    }

    var newArray = new Array(array.length-count);
    var index = 0;
    for (var i = 0; i < array.length; i++) {
        var counter = 0;
        for (var j = 0; j < newArray.length; j++) {
            if(array[i]==newArray[j]) {
                counter++;
                break;
            }
        }
        if(counter==0) {
            newArray[index] = array[i];
            index++;

        }
    }

    return newArray;
}

