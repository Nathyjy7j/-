class SpecialHeader extends HTMLElement{
    connectedCallback(){
        this.innerHTML = `  
        <div style="background-color:antiquewhite;display: flex; justify-content: space-around; ">
        <style>
            a:link{
              
                color:rgba(0, 0, 0, 0.708);
                font-size: 25px;
                text-decoration: none;
            }
            a:visited{
                color:rgba(0, 0, 0, 0.708);
                font-size: 25px;
                text-decoration: none;
            }
            a:hover{
                color: red;
                font-size: 25px;
                text-decoration: underline;
            }
            a:active{
                color: red;
                font-size: 25px;
                text-decoration: underline;
            }
        </style>
      
        </div>

        `
    }
}




console.log("is")
customElements.define('special-header',SpecialHeader)
