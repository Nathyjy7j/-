
function InputUsear(){
    var passworld = "";

    const TextPassaworld  = document.getElementById("TextPassaworld").value;
    const NumberPassaworld = document.getElementById("NumberPassaworld").value;
    var result = document.getElementById("result");

    passworld += TextPassaworld;
    const lengthPassworldText = TextPassaworld.length;
    var isLengthText = false;

    if(lengthPassworldText > 10){
        isLengthText = true;
    }else{
        result.textContent = "הסיסמה לא ארוכה מספיק ";
    }

    passworld += NumberPassaworld;
    const lengthPassworldNumber = NumberPassaworld.length;
    var isLengthNumber = false;

    if(lengthPassworldNumber > 10){
        isLengthNumber = true;
    }else{
        result.textContent = "הסיסמה לא ארוכה מספיק ";
    }

    if(isLengthNumber && isLengthText){
        result.textContent = passworld;
    }
}
