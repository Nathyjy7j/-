function getUserData(){
    var InputName = document.getElementById("InputName").value;
    var InputEmail = document.getElementById("InputEmail").value;
    var InputPassword =  document.getElementById("InputPassword").value;
    //Numbers vars
    var InputAge = Number(document.getElementById("InputAge").value);
    var InputPhone = Number(document.getElementById("InputPhone").value);
    var PrintData =  document.getElementById("PrintData")
    var attitudes = true
    if(InputAge < 18){
        attitudes = false
    }
    var data = {
        Attitudes:attitudes,
        name:InputName,
        Email:InputEmail,
        Password:InputPassword,
        age:InputAge,
        Phone:InputPhone
    }

    console.log(data.name)
    console.log(data.Email)
    console.log(data.Password)
    console.log(data.age)
    console.log(data.Phone)
    PrintData.innerHTML = ` user Name is ${data.name}
    <br> user age is ${data.age}
     <br> user Email is ${data.Email} 
     <br> user password is ${data.Password}
     <br> user phone is ${data.Phone} `
    
}