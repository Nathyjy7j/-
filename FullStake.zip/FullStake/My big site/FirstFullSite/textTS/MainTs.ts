let message :String = "Hello";
console.log(message);