function arrayWords(){
    var words = document.getElementById("is_words").value;
    var array = words.split(" ")
    return array

}

function printError(text){
    var error = document.getElementById("error")
    error.innerHTML = text
}


function getTexBook(){
    var text = document.getElementById("text").value;
    var text2 = text.split(" ")
    var entText = ""
    for(var i=0;i<text2.length;i++){
        entText += text2[i]
    }
    return entText
}

function printBook(){
    const is_lengthBookMex = document.getElementById("is_lengthBookMex");
    const is_lengthBookMin = document.getElementById("is_lengthBookMin");
    const is_words =document.getElementById("is_words");
    var lengthBookMex = document.getElementById("lengthBookMex").value;
    var lengthBookMin = document.getElementById("lengthBookMin").value;


    var array = new Array(0);
    var myText = getTexBook();


    if(is_words.checked){
        array = arrayWords()
    }

    if(is_lengthBookMex.checked){  
        if(myText.length == lengthBookMex){
            console.log("האורך של הספר הוא בגודל הנכון")
        }else{
            console.log("האורך הוא לא נכון")
        }
    }

    if(is_lengthBookMin.checked){
        if(myText.length > lengthBookMin){ 
            console.log("האורך הוא נכון")
        }else if(myText.length < lengthBookMin){
            console.log("האורך ")
        }
    }
}

function  printArray(array){
    for(var i = 0;i< array.length;i++){
        console.log(array[i] + "|")
    }
}

function print(text){
    console.log(text)
}



function printLengthBook(){
    var lengthBook = document.getElementById("lengthBook").value;
    var currentLength = document.getElementById("currentLength")
    lengthBook = Number(lengthBook)
    var text = document.getElementById("text").value;
    var MyText = text.split(" ")
    var entText = ""
    for(var i = 0;i< MyText.length;i++){
        entText += MyText[i]
    }
    currentLength.innerHTML = `${entText.length} האורך הנוכיח של הספר הוא `


}