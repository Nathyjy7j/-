
var scut = 0;
var is_P1 = false;
var is_P2 = false;
var is_P3 = false;

function P1(num){
    if(!is_P1 ){
        if(num == 1){
            scut++

        }else{
            scut--
        }
        printScu()
        is_P1 = true;
    }else{
        document.getElementById("Stop").innerHTML = "ענית כבר על השלאה"
    }
   
}

function P2(num){
    if(!is_P2 ){
        if(num == 1){
            scut++

        }else{
            scut--
        }
        printScu()
        is_P2 = true;
    }else{
        document.getElementById("Stop").innerHTML = "ענית כבר על השלאה"
    }
}


function P3(num){
    if(!is_P3){
        if(num == 1){
            scut++

        }else{
            scut--
        }
        printScu()
        is_P3 = true;
    }else{
        document.getElementById("Stop").innerHTML = "ענית כבר על השלאה"
    }
}

function end(){
    if(is_P1 && is_P2 && is_P1&& is_P3){
        document.getElementById("Stop").innerHTML = "הנקוד הסופי הוא" + scut
    }else{
        document.getElementById("Stop").innerHTML = "תענה על כל השאלות "
    } 
}


function printScu(){
    document.getElementById("Stop").innerHTML = "הניקוד הנוכיח הוא" + scut
}