const myBox = document.getElementById("myBOX");

function P1(){
    myBox.innerHTML ="לחץ עלי " + "😑"
}

myBox.addEventListener("click",P1);