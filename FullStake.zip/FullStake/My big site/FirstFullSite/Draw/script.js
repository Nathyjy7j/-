function Draw1(){
    const numberE = document.getElementById("InputNu1").value;
    var number = numberE;
    var content = document.getElementById("content");
    content.innerHTML = "";
    for(var i = 0; i < number ;i++){
        for(var j = 0; j < number ;j++){
            if(j == i){
                content.innerHTML  += "1";
            }else{
                content.innerHTML  +="0";
            }
        }
        content.innerHTML  += '<br>';
    }
    console.log(number);
}


