const mongoose = require("mongoose");
mongoose.connect('mongodb://127.0.0.1:27017/test', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Database Is Connected'))
    .catch((err) => console.error(err));

const userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    isMarried: Boolean,
    salary: Number,
    gender: String,
});

const User = mongoose.model('User', userSchema);

async function storeInformation() {
    try {
        const user = new User({
            name: 'Ariyan',
            age: 40,
            isMarried: true,
            salary: 50000,
            gender: 'Male',
        });
        await user.save();
        console.log(user);
    } catch (error) {
        console.error(error);
    }
}
storeInformation();
