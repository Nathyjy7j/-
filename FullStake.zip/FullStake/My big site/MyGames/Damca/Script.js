var col1_Bleack = ["row1_1","row3_1","row5_1","row7_1"]
var col1_text_Bleck = ["","","",""]
// לוסיף לאבר עוד אחד
var col2_Bleack = ["row2_2","row4_2","row6_2","row8_2"]
var col2_text_Bleck = ["","","",""]
//
var col3_Bleack = ["row1_3","row3_3","row5_3","row7_3"]
var col3_text_Bleck = ["","","",""]
//
var col4_Bleack = ["row2_4","row4_4","row6_4","row8_4"]
var col4_text_Bleck = ["","","",""]
//
var col5_Bleack = ["row1_5","row3_5","row5_5","row7_5"]
var col5_text_Bleck = ["","","",""]
//
var col6_Bleack = ["row2_6","row4_6","row6_6","row8_6"]
var col6_text_Bleck = ["","","",""]
//
var col7_Bleack = ["row1_7","row3_7","row5_7","row7_7"]
var col7_text_Bleck = ["","","",""]
// 
var col8_Bleack = ["row2_8","row4_8","row6_8","row8_8"]
var col8_text_Bleck = ["","","",""]
strtGame()

function strtGame(){
    drow(col1_Bleack)
    drow(col2_Bleack)
    drow(col3_Bleack)
    drow2(col6_Bleack)
    drow2(col7_Bleack)
    drow2(col8_Bleack)
    enterText("X",col1_text_Bleck)
    enterText("X",col2_text_Bleck)
    enterText("X",col3_text_Bleck)
    enterText("X",col6_text_Bleck)
    enterText("X",col7_text_Bleck)
    enterText("X",col8_text_Bleck)
    
}

function enterText(str,arry){
    for(var i = 0;i<arry.length;i++){
        arry[i] = str
    }
}   

function print(arry){
    for(var i=0;i < arry.length;i++){
       console.log(arry[i] +"|")
    }
}

function drow(arry){
    for(var i=0;i < arry.length;i++){
        document.getElementById(`${arry[i]}`).innerHTML = `<img src="BlackPiece.png">`
    }
}

function drow2(arry){
    for(var i=0;i < arry.length;i++){
        document.getElementById(`${arry[i]}`).innerHTML = ` <img src="WhitePiece.png">`
    }
}



function move(){

}
