document.addEventListener('DOMContentLoaded',()=>{
    const grid = document.documentElement('.grid')
    const width = 8
    const squres = []
    
    
    // יוצר את הגבול של המשחק 
    function creatBord(){
        for(var i=0;i<width*width;i++){
            const square = document.createElement('div')
            // createElement זה יוצר אלמנט נוסף
            grid.appendChild(square)
            // מוסיף ילד לאלמנט הראשי 
            squres.push(square)
        }
    }
    creatBord()
})
