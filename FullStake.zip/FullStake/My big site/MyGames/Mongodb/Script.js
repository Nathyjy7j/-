var _name = "";
var _score = 13;
var _nameGame = 


const mongoose = require("mongoose");
mongoose.connect('mongodb://127.0.0.1:27017/test', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Database Is Connected'))
    .catch((err) => console.error(err));

const userSchema = new mongoose.Schema({
    name: String,
    nameGame:String,
    score:Number,
});

const User = mongoose.model('User', userSchema);

async function storeInformation() {
    try {
        const user = new User({
         name:_name,
         nameGame:_nameGame,
         score:_score,
        });
        await user.save();
        console.log(user);
    } catch (error) {
        console.error(error);
    }
}
storeInformation();
