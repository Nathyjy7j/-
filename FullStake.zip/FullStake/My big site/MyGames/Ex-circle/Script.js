var col1_1 = false;
var col1_2 = false;
var col1_3 = false;

var col2_1 = false;
var col2_2 = false;
var col2_3 = false;

var col3_1 = false;
var col3_2 = false;
var col3_3 = false;

var dateGame = document.getElementById("dateGame");
var button1 = document.getElementById("button1");
var button2 = document.getElementById("button2");
var button3 = document.getElementById("button3");
var button4 = document.getElementById("button4");
var button5 = document.getElementById("button5");
var button6 = document.getElementById("button6");
var button7= document.getElementById("button7");
var button8 = document.getElementById("button8");
var button9 = document.getElementById("button9");

var Textol1_1 = "";
var Textol1_2 = "";
var Textol1_3 = "";

var Textol2_1 ="";
var Textol2_2 = "";
 var Textol2_3 = "";

var Textol3_1 = "";
var Textol3_2 = "";
var Textol3_3 = ""

var Player  = true;
var victory = false;
var PlayerWin; 

function is_col1_1(){
    if(victory == false){
        if (col1_1 == false){
            if(Player){
                button1.textContent = "X";
                Textol1_1 = "X";
            }else{
                button1.textContent = "O";
                Textol1_1 = "O";
            }
            flipGame();
            col1_1 = true;
        }
    }
    CHeckPlayer();
}

function is_col1_2(){
    if(victory == false){
        if (col1_2 == false){
            if(Player){
                button2.textContent = "X";
                Textol1_2 = "X";
            }else{
                button2.textContent = "O";
                Textol1_2 = "O";
            }
            flipGame();
            col1_2 = true;
        }
    }
    CHeckPlayer();
}

function is_col1_3(){
    if(victory == false){
        if (col1_3 == false){
            if(Player){
                button3.textContent = "X";
                Textol1_3 = "X";
            }else{
                Textol1_3 = "O";
                button3.textContent = "O";
            }
            flipGame();
            col1_3 = true;
            
        }
    }
    CHeckPlayer();
}


function is_col2_1(){
    if(victory == false){
        if (col2_1 == false){
            if(Player){
                button4.textContent = "X";
                Textol2_1 = "X";
            }else{
                button4.textContent = "O";
                Textol2_1 = "O";
            }
            col2_1 = true;
            flipGame();
        }
    }
    CHeckPlayer();
}


function is_col2_2(){
    if(victory == false){
        if (col2_2 == false){
            if(Player){
                button5.textContent = "X";
                Textol2_2 = "X";
            }else{
                Textol2_2 = "O";
                button5.textContent = "O";
            }
            col2_2 = true;
            flipGame();
        }
    }
    CHeckPlayer();
}

function is_col2_3(){
    if(victory == false){
        if (col2_3 == false){
            if(Player){
                button6.textContent = "X";
                Textol2_3 = "X";
            }else{
                button6.textContent = "O";
                Textol2_3 = "O";
            }
            col2_3 = true;
            flipGame();
        }
    }
    CHeckPlayer();
}

function is_col3_1(){
    if(victory == false){
        if (col3_1 == false){
            if(Player){
                button7.textContent = "X";
                Textol3_1 = "X";
            }else{
                button7.textContent = "O";
                Textol3_1 = "O";
            }
            col3_1 = true;
            flipGame();
        }
    }
    CHeckPlayer();
}

function is_col3_2(){
    if(victory == false){
        if (col3_2 == false){
            if(Player){
                button8.textContent = "X";
                Textol3_2 = "X";
            }else{
                button8.textContent = "O";
                Textol3_2= "O";
            }
            col3_2 = true;
            flipGame();
        }
    }
    CHeckPlayer();
}

function is_col3_3(){
    if(victory == false){
        if (col3_3 == false){
            if(Player){
                button9.textContent = "X";
                Textol3_3 = "X";
            }else{
                button9.textContent = "O";
                Textol3_3 = "O";
            }
            col3_3 = true;
            flipGame();
        }
    }
    CHeckPlayer();
}


function flipGame(){
    if(Player == true){
       
        dateGame.textContent = "התור התחלף לעיגול";
        Player = false;
        checkPlayer("O");
    }else if(Player == false){
        dateGame.textContent = "התור התחלף אקס";
        Player =true;
        checkPlayer("X");
    }
}

function CHeckPlayer(){
    if(Player == true){
        checkPlayer("X");
    }
    if(Player == false){
        checkPlayer("O");
    }

}

function checkPlayer(sign){
    if(Textol1_1 == sign && Textol1_2 == sign && Textol1_3 == sign){
        Playervictory();
    }
    if(Textol2_1 == sign && Textol2_2 == sign && Texto2_3 == sign){
        Playervictory();
    }
    if(Textol3_1 == sign && Textol3_2 == sign && Textol3_3 == sign){
        Playervictory();
    }
    if(Textol1_1 == sign && Textol2_2 == sign && Textol3_3 == sign){
        Playervictory();
    }
    if(Textol1_3 == sign && Textol2_2 == sign && Textol3_1 == sign){
        Playervictory();
    }
    if(Textol1_3 == sign && Textol2_1 == sign && Textol3_1 == sign){
        Playervictory();
    }
    if(Textol1_2 == sign && Textol2_2 == sign && Textol3_2 == sign){
        Playervictory();
    }
    if(Textol1_3 == sign && Textol2_3 == sign && Textol3_3 == sign){
        Playervictory();
    }
}

function Playervictory(){
    if(Player == true){
        victory  = true;
        dateGame.textContent = "המנצח הוא אקס"
    }
    if(Player == false){
        victory  = true;
        dateGame.textContent = "המנצח הוא עיגול"
    }
}

CHeckPlayer();

