document.getElementById("root").innerHTML = `
<a href="/MyGames/ROCK_PAPER_ SCISSORS/index.html">אבן נייר מספרים</a>
<a href="/MyGames/Ex-circle/page3.html">איקס עיגול</a>
<a href="/MyGames/Connect 4/page4.html">ארבע בשורה</a>
<a href="/MyGames/You_drew_cards/inde.html">משחק כלפים</a>
`