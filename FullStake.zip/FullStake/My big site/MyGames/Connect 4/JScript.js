var playerRed = "R";
var  playerGren = "G";
var currtPlayer = true;
var gameOver = false;
var board;
var rows = 1;
var coulumns = 7;
var Mytable = document.getElementById("Mytable")
///1
var row1_7 = document.getElementById("1_7");
var row1_6 = document.getElementById("1_6");
var row1_5 = document.getElementById("1_5");
var row1_4 = document.getElementById("1_4");
var row1_3 = document.getElementById("1_3");
var row1_2 = document.getElementById("1_2");
var row1_1 = document.getElementById("1_1");
//2
var row2_7 = document.getElementById("2_7");
var row2_6 = document.getElementById("2_6");
var row2_5 = document.getElementById("2_5");
var row2_4 = document.getElementById("2_4");
var row2_3 = document.getElementById("2_3");
var row2_2 = document.getElementById("2_2");
var row2_1 = document.getElementById("2_1");
//3
var row3_7 = document.getElementById("3_7");
var row3_6 = document.getElementById("3_6");
var row3_5 = document.getElementById("3_5");
var row3_4 = document.getElementById("3_4");
var row3_3 = document.getElementById("3_3");
var row3_2 = document.getElementById("3_2");
var row3_1 = document.getElementById("3_1");
//4
var row4_7 = document.getElementById("4_7");
var row4_6 = document.getElementById("4_6");
var row4_5 = document.getElementById("4_5");
var row4_4 = document.getElementById("4_4");
var row4_3 = document.getElementById("4_3");
var row4_2 = document.getElementById("4_2");
var row4_1 = document.getElementById("4_1");
//5
var row5_7 = document.getElementById("5_7");
var row5_6 = document.getElementById("5_6");
var row5_5 = document.getElementById("5_5");
var row5_4 = document.getElementById("5_4");
var row5_3 = document.getElementById("5_3");
var row5_2 = document.getElementById("5_2");
var row5_1 = document.getElementById("5_1");
//6
var row6_7 = document.getElementById("6_7");
var row6_6 = document.getElementById("6_6");
var row6_5 = document.getElementById("6_5");
var row6_4 = document.getElementById("6_4");
var row6_3 = document.getElementById("6_3");
var row6_2 = document.getElementById("6_2");
var row6_1 = document.getElementById("6_1");
//7
var row7_7 = document.getElementById("7_7");
var row7_6 = document.getElementById("7_6");
var row7_5 = document.getElementById("7_5");
var row7_4 = document.getElementById("7_4");
var row7_3 = document.getElementById("7_3");
var row7_2 = document.getElementById("7_2");
var row7_1 = document.getElementById("7_1");
//בולאני
///1
var is_row1_7 = false;
var is_row1_6 =  false;
var is_row1_5 =  false;
var is_row1_4 = false;
var is_row1_3 =  false;;
var is_row1_2 =  false;
var is_row1_1 =  false;
//2
var is_row2_7 =  false;
var is_row2_6 =  false;
var is_row2_5 =  false;
var is_row2_4 =  false;
var is_row2_3 =  false;
var is_row2_2 =  false;
var is_row2_1 =  false;
//3
var is_row3_7 =  false;
var is_row3_6 =  false;
var is_row3_5 =  false;
var is_row3_4 =  false;
var is_row3_3 =  false;
var is_row3_2 =  false;
var is_row3_1 =  false;
//4
var is_row4_7 =  false;
var is_row4_6 =  false;
var is_row4_5 =  false;
var is_row4_4 =  false;
var is_row4_3 =  false;
var is_row4_2 =  false;
var is_row4_1 =  false;
//5
var is_row5_7 =  false;
var is_row5_6 =  false;
var is_row5_5 =  false;
var is_row5_4 =  false;
var is_row5_3 =  false;
var is_row5_2 =  false;
var is_row5_1 =  false;
//6
var is_row6_7 =  false;
var is_row6_6 =  false;
var is_row6_5 =  false;
var is_row6_4 =  false;
var is_row6_3 =  false;
var is_row6_2 =  false;
var is_row6_1 =  false;
//7
var is_row7_7 =  false;
var is_row7_6 =  false;
var is_row7_5 =  false;
var is_row7_4 =  false;
var is_row7_3 =  false;
var is_row7_2 =  false;
var is_row7_1 =  false;

var isFullrow1 = false;
var isFullrow2 = false;
var isFullrow3 = false;
var isFullrow4 = false;
var isFullrow5 = false;
var isFullrow6 = false;
var isFullrow7 = false;

var noWin = false

function print(str){
    // console.log("-----------------")
    // console.log(str)
    // console.log("-----------------")
}



function printWoner(){
  
}

function PlayerFlip(){
    if(!noWin){
        if(currtPlayer){
            PlayerWin("G");
            currtPlayer = false
        }else{
            PlayerWin("R");
            currtPlayer =  true
        }
    }
}

function checkPlayer(){
    var Winer = document.getElementById("Winer");
    if(currtPlayer){
        Winer.innerHTML = "הנצח הוא השחקן הירוק"
        noWin = true
    }else if(!currtPlayer){
        Winer.innerHTML = "המנצח הוא השחקן האדום"
        noWin = true
    }
}

function StringIs(text1,text2,text3,text4,sign){
    if(text1 == sign && text2 == sign &&  text3 == sign && text4 == sign){
        checkPlayer()
    }
}

function PlayerWin(sign){
    if(is_row1_1 && is_row2_1 && is_row3_1 && is_row4_1){
        StringIs(text_row1_1,text_row2_1,text_row3_1,text_row4_1,sign)
    }
    if(is_row1_2 && is_row2_2 && is_row3_2 && is_row4_2){
        StringIs(text_row1_2,text_row2_2,text_row3_2,text_row4_2,sign)
    }
    if(is_row1_3 && is_row2_3 && is_row3_3 && is_row4_3){
        StringIs(text_row1_3,text_row2_3,text_row3_3,text_row4_3,sign)
    }
    if(is_row1_4 && is_row2_4 && is_row3_4 && is_row4_4){
        StringIs(text_row1_4,text_row2_4,text_row3_4,text_row4_4,sign)
    }
    if(is_row1_5 && is_row2_5 && is_row3_5 && is_row4_5){
        StringIs(text_row1_5,text_row2_5,text_row3_5,text_row4_5,sign)
    }
    if(is_row1_6 && is_row2_6 && is_row3_6 && is_row4_6){
        StringIs(text_row1_6,text_row2_6,text_row3_6,text_row4_6,sign)
    }
    if(is_row1_7 && is_row2_7 && is_row3_7 && is_row4_7){
        StringIs(text_row1_6,text_row2_6,text_row3_6,text_row4_6,sign)
    }

    //--
    if(is_row4_1 && is_row5_1 && is_row6_1 && is_row7_1){
        StringIs(text_row4_1,text_row5_1,text_row6_1,text_row7_1,sign)
    }
    if(is_row4_2 && is_row5_2 && is_row6_2 && is_row7_2){
        StringIs(text_row4_2,text_row5_2,text_row6_2,text_row7_2,sign)
    }
    if(is_row4_3 && is_row5_3 && is_row6_3 && is_row7_3){
        StringIs(text_row4_3,text_row5_3,text_row6_3,text_row7_3,sign)
    }
    if(is_row4_4 && is_row5_4 && is_row6_4 && is_row7_4){
        StringIs(text_row4_4,text_row5_4,text_row6_4,text_row7_4,sign)
    }
    if(is_row4_5 && is_row5_5 && is_row6_5 && is_row7_5){
        StringIs(text_row4_5,text_row5_5,text_row6_5,text_row7_5,sign)
    }
    if(is_row4_6 && is_row5_6 && is_row6_6 && is_row7_6){
        StringIs(text_row4_6,text_row5_6,text_row6_6,text_row7_6,sign)
    }
    if(is_row4_7 && is_row5_7 && is_row6_7 && is_row7_7){
        StringIs(text_row4_7,text_row5_7,text_row6_7,text_row7_7,sign)
    }
    if(is_row1_1 && is_row1_2 && is_row1_3 && is_row1_4){
        StringIs(text_row1_1,text_row1_4,text_row1_4,text_row1_4,sign)
    }
    if(is_row1_4 && is_row1_5 && is_row1_6 && is_row1_7){
        StringIs(text_row1_4,text_row1_5,text_row1_6,text_row1_7,sign)
    }
    if(is_row2_1 && is_row2_2 && is_row2_3 && is_row2_4){
        StringIs(text_row2_1,text_row2_2,text_row2_3,text_row2_4,sign)
    }
    if(is_row2_4 && is_row2_5 && is_row2_6 && is_row2_7){
        StringIs(text_row2_4,text_row2_5,text_row2_6,text_row2_7,sign)
    }
    if(is_row3_1 && is_row3_2 && is_row3_3 && is_row3_4){
        StringIs(text_row3_1,text_row3_2,text_row3_3,text_row3_4,sign)
    }
    if(is_row3_4 && is_row3_5 && is_row3_6 && is_row3_7){
        StringIs(text_row3_4,text_row3_5,text_row3_6,text_row3_7,sign)
    }
    if(is_row4_1 && is_row4_2 && is_row4_3 && is_row4_4){
        StringIs(text_row4_1,text_row4_2,text_row4_3,text_row4_4,sign)
    }
    if(is_row4_4 && is_row4_5 && is_row4_6 && is_row4_7){
        StringIs(text_row4_4,text_row4_5,text_row4_6,text_row4_7,sign)
    }
    if(is_row5_1 && is_row5_2 && is_row5_3 && is_row5_4){
        StringIs(text_row5_1,text_row5_2,text_row5_3,text_row5_4,sign)
    }
    if(is_row5_4 && is_row5_5 && is_row5_6 && is_row5_7){
        StringIs(text_row5_4,text_row5_5,text_row5_6,text_row5_7,sign)
    }
    if(is_row6_1 && is_row6_2 && is_row6_3 && is_row6_4){
        StringIs(text_row6_1,text_row6_2,text_row6_3,text_row6_4,sign)
    }
    if(is_row6_4 && is_row6_5 && is_row6_6 && is_row6_7){
        StringIs(text_row6_4,text_row6_5,text_row6_6,text_row6_7,sign)
    }
    if(is_row7_1 && is_row7_2 && is_row7_3 && is_row7_4){
        StringIs(text_row7_1,text_row7_2,text_row7_3,text_row7_4,sign)
    }
    if(is_row7_4 && is_row7_5 && is_row7_6 && is_row7_7){
        StringIs(text_row7_4,text_row7_5,text_row7_6,text_row7_7,sign)
    }
    // אלחסונים
    if(is_row1_4 && is_row2_5 && is_row3_6 && is_row4_7){
        StringIs(text_row1_4,text_row2_5,text_row3_6,text_row4_7,sign)
    }
    if(is_row1_4 && is_row2_3 && is_row3_2 && is_row4_1){
        StringIs(text_row1_4,text_row2_3,text_row3_2,text_row4_1,sign)
    }
    if(is_row2_4 && is_row3_5 && is_row4_6 && is_row5_7){
        StringIs(text_row2_4,text_row3_5,text_row4_6,text_row5_7,sign)
    }
    if(is_row2_4 && is_row3_3 && is_row4_2 && is_row5_1){
        StringIs(text_row2_4,text_row3_3,text_row4_2,text_row5_1,sign)
    }
    if(is_row3_4 && is_row4_5 && is_row5_6 && is_row6_7){
        StringIs(text_row3_4,text_row4_5,text_row5_6,text_row6_7,sign)
    }
    if(is_row3_4 && is_row4_3 && is_row5_2 && is_row6_1){
        StringIs(text_row3_4,text_row4_3,text_row5_2,text_row6_1,sign)
    }
}

function row1(){
    var doown = true;
    if(!noWin){
        if(!isFullrow1){
                if(!is_row1_1){
                    is_row1_1 = true;
                    if(currtPlayer){
                        row1_1.innerHTML = "G"
                        text_row1_1 = "G"
                        PlayerFlip();
                    }else{
                        row1_1.innerHTML = "R"
                        text_row1_1 = "R"
                        PlayerFlip();
                    }
                }else if (!is_row1_2){
                    is_row1_2 = true;
                    if(currtPlayer){
                        row1_2.innerHTML = "G"
                        text_row1_2 = "G"
                        PlayerFlip();
                    }else{
                        row1_2.innerHTML = "R"
                        text_row1_2 = "R"
                        PlayerFlip();
                    }  
                }else if(!is_row1_3){
                    
                    is_row1_3 = true;
                    if(currtPlayer){
                        row1_3.innerHTML = "G"
                        text_row1_3 = "G"
                        PlayerFlip();
                    }else{
                        row1_3.innerHTML = "R"
                        text_row1_3 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row1_4){
                    is_row1_4 = true
                    if(currtPlayer){
                        row1_4.innerHTML = "G"
                        text_row1_4 = "G"
                        PlayerFlip();
                    }else{
                        row1_4.innerHTML = "R"
                        text_row1_4 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row1_5){
                    is_row1_5 = true;
                    if(currtPlayer){
                        row1_5.innerHTML = "G"
                        text_row1_5 = "G"
                        PlayerFlip();
                    }else{
                        row1_5.innerHTML = "R"
                        text_row1_5 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row1_6){
                    is_row1_6 = true;
                    if(currtPlayer){
                        row1_6.innerHTML = "G"
                        text_row1_6 = "G"
                        PlayerFlip();
                    }else{
                        row1_6.innerHTML = "R"
                        text_row1_6 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row1_7){
                    is_row1_7 = true
                    isFullrow1 = true;
                    if(currtPlayer){
                        row1_7.innerHTML = "G"
                        text_row1_7 = "G"

                        PlayerFlip();
                    }else{
                        row1_7.innerHTML = "R"
                        text_row1_7 = "R"
                        PlayerFlip();
                    }
            }
            
        }else{
            var text = document.getElementById("text");
            text.innerHTML = "השורה כבר מלאה"
        }
    }else{
        printWoner();
    }
}

function row2(){
    var doown = true;
    if(!noWin){
        if(!isFullrow2){
                if(!is_row2_1){
                    is_row2_1 = true;
                    if(currtPlayer){
                        row2_1.innerHTML = "G"
                        text_row2_1 = "G"
                        PlayerFlip();
                    }else{
                        row2_1.innerHTML = "R"
                        text_row2_1 = "R"
                        PlayerFlip();
                    }
                }else if (!is_row2_2){
                    is_row2_2 = true;
                    if(currtPlayer){
                        row2_2.innerHTML = "G"
                        text_row2_2 = "G"
                        PlayerFlip();
                    }else{
                        row2_2.innerHTML = "R"
                        text_row2_2 = "R"
                        PlayerFlip();
                    }  
                }else if(!is_row2_3){
                    
                    is_row2_3 = true;
                    if(currtPlayer){
                        row2_3.innerHTML = "G"
                        text_row1_3 = "G"
                        PlayerFlip();
                    }else{
                        row2_3.innerHTML = "R"
                        text_row2_3 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row2_4){
                    is_row2_4 = true
                    if(currtPlayer){
                        row2_4.innerHTML = "G"
                        text_row2_4 = "G"
                        PlayerFlip();
                    }else{
                        row2_4.innerHTML = "R"
                        text_row2_4 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row2_5){
                    is_row2_5 = true;
                    if(currtPlayer){
                        row2_5.innerHTML = "G"
                        text_row2_5 = "G"
                        PlayerFlip();
                    }else{
                        row2_5.innerHTML = "R"
                        text_row2_5 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row2_6){
                    is_row2_6 = true;
                    if(currtPlayer){
                        row2_6.innerHTML = "G"
                        text_row2_6 = "G"
                        PlayerFlip();
                    }else{
                        row2_6.innerHTML = "R"
                        text_row2_6 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row2_7){
                    is_row2_7 = true
                    isFullrow2 = true;
                    if(currtPlayer){
                        row2_7.innerHTML = "G"
                        text_row2_7 = "G"

                        PlayerFlip();
                    }else{
                        row2_7.innerHTML = "R"
                        text_row2_7 = "R"
                        PlayerFlip();
                    }
                }
        }else{
            var text = document.getElementById("text");
            text.innerHTML = "השורה כבר מלאה"
        }
    }else{
        printWoner();
    }
   
}


function row3(){
    if(!noWin){
        if(!isFullrow3){
                if(!is_row3_1){
                    is_row3_1 = true;
                    if(currtPlayer){
                        row3_1.innerHTML = "G"
                        text_row3_1 = "G"
                        PlayerFlip();
                    }else{
                        row3_1.innerHTML = "R"
                        text_row3_1 = "R"
                        PlayerFlip();
                    }
                }else if (!is_row3_2){
                    is_row3_2 = true;
                    if(currtPlayer){
                        row3_2.innerHTML = "G"
                        text_row3_2 = "G"
                        PlayerFlip();
                    }else{
                        row3_2.innerHTML = "R"
                        text_row3_2 = "R"
                        PlayerFlip();
                    }  
                }else if(!is_row3_3){
                    
                    is_row3_3 = true;
                    if(currtPlayer){
                        row3_3.innerHTML = "G"
                        text_row3_3 = "G"
                        PlayerFlip();
                    }else{
                        row3_3.innerHTML = "R"
                        text_row3_3 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row3_4){
                    is_row3_4 = true
                    if(currtPlayer){
                        row3_4.innerHTML = "G"
                        text_row3_4 = "G"
                        PlayerFlip();
                    }else{
                        row3_4.innerHTML = "R"
                        text_row3_4 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row3_5){
                    is_row3_5 = true;
                    if(currtPlayer){
                        row3_5.innerHTML = "G"
                        text_row3_5 = "G"
                        PlayerFlip();
                    }else{
                        row3_5.innerHTML = "R"
                        text_row3_5 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row3_6){
                    is_row3_6 = true;
                    if(currtPlayer){
                        row3_6.innerHTML = "G"
                        text_row3_6 = "G"
                        PlayerFlip();
                    }else{
                        row3_6.innerHTML = "R"
                        text_row3_6 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row3_7){
                    is_row3_7 = true
                    isFullrow3 = true;
                    if(currtPlayer){
                        row3_7.innerHTML = "G"
                        text_row3_7 = "G"

                        PlayerFlip();
                    }else{
                        row3_7.innerHTML = "R"
                        text_row3_7 = "R"
                        PlayerFlip();
                    }
                }
        }else{
            var text = document.getElementById("text");
            text.innerHTML = "השורה כבר מלאה"
        }
    }else{
        printWoner();
    }
}


function row4(){
    if(!noWin){
        if(!isFullrow4){
                if(!is_row4_1){
                    is_row4_1 = true;
                    if(currtPlayer){
                        row4_1.innerHTML = "G"
                        text_row4_1 = "G"
                        PlayerFlip();
                    }else{
                        row4_1.innerHTML = "R"
                        text_row4_1 = "R"
                        PlayerFlip();
                    }
                }else if (!is_row4_2){
                    is_row4_2 = true;
                    if(currtPlayer){
                        row4_2.innerHTML = "G"
                        text_row4_2 = "G"
                        PlayerFlip();
                    }else{
                        row4_2.innerHTML = "R"
                        text_row4_2 = "R"
                        PlayerFlip();
                    }  
                }else if(!is_row4_3){
                    
                    is_row4_3 = true;
                    if(currtPlayer){
                        row4_3.innerHTML = "G"
                        text_row4_3 = "G"
                        PlayerFlip();
                    }else{
                        row4_3.innerHTML = "R"
                        text_row4_3 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row4_4){
                    is_row4_4 = true
                    if(currtPlayer){
                        row4_4.innerHTML = "G"
                        text_row4_4 = "G"
                        PlayerFlip();
                    }else{
                        row4_4.innerHTML = "R"
                        text_row4_4 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row4_5){
                    is_row4_5 = true;
                    if(currtPlayer){
                        row4_5.innerHTML = "G"
                        text_row4_5 = "G"
                        PlayerFlip();
                    }else{
                        row4_5.innerHTML = "R"
                        text_row4_5 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row4_6){
                    is_row4_6 = true;
                    if(currtPlayer){
                        row4_6.innerHTML = "G"
                        text_row4_6 = "G"
                        PlayerFlip();
                    }else{
                        row4_6.innerHTML = "R"
                        text_row4_6 = "R"
                        PlayerFlip();
                    }
                }else if(!is_row4_7){
                    is_row4_7 = true
                    isFullrow4 = true;
                    if(currtPlayer){
                        row4_7.innerHTML = "G"
                        text_row4_7 = "G"

                        PlayerFlip();
                    }else{
                        row4_7.innerHTML = "R"
                        text_row4_7 = "R"
                        PlayerFlip();
                    }
                }
        }else{
            var text = document.getElementById("text");
            text.innerHTML = "השורה כבר מלאה"
        }
    }else{
        printWoner();
    }
}

function row5(){
    var doown = true;
   if(!noWin){
    if(!isFullrow5){
        switch(doown){
            case is_row5_7:
                isFullrow5 = true;
                if(currtPlayer){
                    row5_7.innerHTML = "G"
                    text_row5_7 = "G"
                    PlayerFlip();
                }else{
                    row5_7.innerHTML = "R"
                    text_row5_7 = "R"
                    PlayerFlip();
                }
         
            break;
            case is_row5_6:
                is_row5_7 = true;
                if(currtPlayer){
                    row5_6.innerHTML = "G"
                    text_row5_6 = "G"
                    PlayerFlip();
                }else{
                    row5_6.innerHTML = "R"
                    text_row5_6 = "R"
                    PlayerFlip();
                }
              
            break;
            case is_row5_5:
                is_row5_6 = true;
                if(currtPlayer){
                    row5_5.innerHTML = "G"
                    text_row5_5 = "G"
                    PlayerFlip();
                }else{
                    row5_5.innerHTML = "R"
                    text_row5_5 = "R"
                    PlayerFlip();
                }
              
            break;
            case is_row5_4:
                is_row5_5 = true;
                if(currtPlayer){
                    row5_4.innerHTML = "G"
                    text_row5_4 = "G"
                    PlayerFlip();
                }else{
                    row5_4.innerHTML = "R"
                    text_row5_4 = "R"
                    PlayerFlip();
                }
            
            break;
            case is_row5_3:
                is_row5_4 = true;
                if(currtPlayer){
                    row5_3.innerHTML = "G"
                    text_row5_3 = "G"
                    PlayerFlip();
                }else{
                    row5_3.innerHTML = "R"
                    text_row5_3 = "R"
                    PlayerFlip();
                }
        
            break;
            case is_row5_2:
                is_row5_3 = true;
                if(currtPlayer){
                    row5_2.innerHTML = "G"
                    text_row5_2 = "G"
                    PlayerFlip();
                }else{
                    row5_2.innerHTML = "R"
                    text_row5_2 = "R"
                    PlayerFlip();
                }
         
            break;
            case !is_row5_1:
                is_row5_1 = true;
                is_row5_2 = true;
                if(currtPlayer){
                    row5_1.innerHTML = "G"
                    text_row5_1 = "G"
                    PlayerFlip();
                }else{
                    row5_1.innerHTML = "R"
                    text_row5_1 = "R"
                    PlayerFlip();
                }
            
            break;
        }
    }else{
        var text = document.getElementById("text");
        text.innerHTML = "השורה כבר מלאה"
    }
   }else{
    printWoner();
    }
}


function row6(){
    var doown = true;
   if(!noWin){
    if(!isFullrow6){
        switch(doown){
            case is_row6_7:
                isFullrow6 = true;
                if(currtPlayer){
                    row6_7.innerHTML = "G"
                    text_row6_7 = "G"
                    PlayerFlip();
                }else{
                    row6_7.innerHTML = "R"
                    text_row6_7 = "R"
                    PlayerFlip();
                }
           
            break;
            case is_row6_6:
                is_row6_7 = true;
                if(currtPlayer){
                    row6_6.innerHTML = "G"
                    text_row6_6 = "G"
                    PlayerFlip();
                }else{
                    row6_6.innerHTML = "R"
                    text_row6_6 = "R"
                    PlayerFlip();
                }
          
            break;
            case is_row6_5:
                is_row6_6 = true;
                if(currtPlayer){
                    row6_5.innerHTML = "G"
                    text_row6_5 = "G"
                    PlayerFlip();
                }else{
                    row6_5.innerHTML = "R"
                    text_row6_5 = "R"
                    PlayerFlip();
                }
             
            break;
            case is_row6_4:
                is_row6_5 = true;
                if(currtPlayer){
                    row6_4.innerHTML = "G"
                    text_row6_4 = "G"
                    PlayerFlip();
                }else{
                    row6_4.innerHTML = "R"
                    text_row6_4 = "R"
                    PlayerFlip();
                }
          
            break;
            case is_row6_3:
                is_row6_4 = true;
                if(currtPlayer){
                    row6_3.innerHTML = "G"
                    text_row6_3 = "G"
                    PlayerFlip();
                }else{
                    row6_3.innerHTML = "R"
                    text_row6_3 = "R"
                    PlayerFlip();
                }
      
            break;
            case is_row6_2:
                is_row6_3 = true;
                if(currtPlayer){
                    row6_2.innerHTML = "G"
                    text_row6_2 = "G"
                    PlayerFlip();
                }else{
                    row6_2.innerHTML = "R"
                    text_row6_2 = "R"
                    PlayerFlip();
                }
         
            break;
            case !is_row6_1:
                is_row6_1 = true;
                is_row6_2 = true;
                if(currtPlayer){
                    row6_1.innerHTML = "G"
                    text_row6_1 = "G"
                    PlayerFlip();
                }else{
                    row6_1.innerHTML = "R"
                    text_row6_1 = "R"
                    PlayerFlip();
                }
          
            break;
        }
        PlayerWin()
    }else{
        var text = document.getElementById("text");
        text.innerHTML = "השורה כבר מלאה"
    }
   }else{
    printWoner();
    }
}

function row7(){
    var doown = true;
   if(!noWin){
    if(!isFullrow7){
        switch(doown){
            case is_row7_7:
                isFullrow7 = true;
                if(currtPlayer){
                    row7_7.innerHTML = "G"
                    text_row7_7 = "G"
                    PlayerFlip();
                }else{
                    row7_7.innerHTML = "R"
                    text_row7_7 = "R"
                    PlayerFlip();
                }
            break;
            case is_row7_6:
                is_row7_7 = true;
                if(currtPlayer){
                    row7_6.innerHTML = "G"
                    text_row7_6 = "G"
                    PlayerFlip();
                }else{
                    row7_6.innerHTML = "R"
                    text_row7_6 = "R"
                    PlayerFlip();
                }
              
            break;
            case is_row7_5:
                is_row7_6 = true;
                if(currtPlayer){
                    row7_5.innerHTML = "G"
                    text_row7_5 = "G"
                    PlayerFlip();
                }else{
                    row7_5.innerHTML = "R"
                    text_row7_5 = "R"
                    PlayerFlip();
                }
             
            break;
            case is_row7_4:
                is_row7_5 = true;
                if(currtPlayer){
                    row7_4.innerHTML = "G"
                    text_row7_4 = "G"
                    PlayerFlip();
                }else{
                    row7_4.innerHTML = "R"
                    text_row7_4 = "R"
                    PlayerFlip();
                }
              
            break;
            case is_row7_3:
                is_row7_4 = true;
                if(currtPlayer){
                    row7_3.innerHTML = "G"
                    text_row7_3 = "G"
                    PlayerFlip();
                }else{
                    row7_3.innerHTML = "R"
                    text_row7_3 = "R"
                    PlayerFlip();
                }
         
            break;
            case is_row7_2:
                is_row7_3 = true;
                if(currtPlayer){
                    row7_2.innerHTML = "G"
                    text_row7_2 = "G"
                    PlayerFlip();
                }else{
                    row7_2.innerHTML = "R"
                    text_row7_2 = "R"
                    PlayerFlip();
                }
             
            break;
            case !is_row7_1:
                is_row7_1 = true;
                is_row7_2 = true;
                if(currtPlayer){
                    row7_1.innerHTML = "G"
                    text_row7_1 = "G"
                    PlayerFlip();
                }else{
                    row7_1.innerHTML = "R"
                    text_row7_1 = "R"
                    PlayerFlip();
                }
               
            break;
        }
    }else{
        var text = document.getElementById("text");
        text.innerHTML = "השורה כבר מלאה"
    }
   }else{
    printWoner();
    }
}

//מחרוזת/
///1
var text_row1_7 = "";
var text_row1_6 =  "";
var text_row1_5 =  "";
var text_row1_4 = "";
var text_row1_3 =  "";
var text_row1_2 =  "";
var text_row1_1 =  "";
//2
var text_row2_7 =  "";
var text_row2_6 =  "";
var text_row2_5 =  "";
var text_row2_4 =  "";
var text_row2_3 =  "";
var text_row2_2 =  "";
var text_row2_1 =  "";
//3
var text_row3_7 =  "";
var text_row3_6 =  "";
var text_row3_5 =  "";
var text_row3_4 =  "";
var text_row3_3 =  "";
var text_row3_2 =  "";
var text_row3_1 =  "";
//4
var text_row4_7 =  "";
var text_row4_6 =  "";
var text_row4_5 =  "";
var text_row4_4 =  "";
var text_row4_3 =  "";
var text_row4_2 =  "";
var text_row4_1 =  "";
//5
var text_row5_7 =  "";
var text_row5_6 =  "";
var text_row5_5 =  "";
var text_row5_4 =  "";
var text_row5_3 =  "";
var text_row5_2 =  "";
var text_row5_1 =  "";
//6
var text_row6_7 =  "";
var text_row6_6 =  "";
var text_row6_5 =  "";
var text_row6_4 =  "";
var text_row6_3 =  "";
var text_row6_2 =  "";
var text_row6_1 =  "";
//7
var text_row7_7 =  "";
var text_row7_6 =  "";
var text_row7_5 =  "";
var text_row7_4 =  "";
var text_row7_3 =  "";
var text_row7_2 =  "";
var text_row7_1 =  "";