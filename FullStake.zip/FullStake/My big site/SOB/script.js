document.addEventListener("DOMContentLoaded", function() {

    // מזהה אלמנטים לפי ID
    //
    // var adElementsById = ['ad', 'ads', 'adsense', 'adContainer'];
    // adElementsById.forEach(function(id) {
    //   var element = document.getElementById(id);
    //   if (element) {
    //     element.style.display = 'none';
    //   }
    // });
  
    // מזהה אלמנטים לפי class
    var adElementsByClass = ['ad', 'ads', 'advertisement', 'ad-container'];
    adElementsByClass.forEach(function(cls) {
      var elements = document.getElementsByClassName(cls);
      for (var i = 0; i < elements.length; i++) {
        if(elements[i].class == "afs_ads ad-placement" || elements[i].class == "jw-captions jw-reset jw-captions-enabled" || elements[i].class == "mb-4 mb-lg-5" || elements[i].class == "w-captions-window jw-reset" || elements[i].class == "jw-captions-text jw-reset"){
            elements[i].style.display = 'none';
        }
      }
    });
  
    // מזהה אלמנטים לפי תגיות
    var adElementsByTag = ['iframe', 'img', 'div'];
    adElementsByTag.forEach(function(tag) {
      var elements = document.getElementsByTagName(tag);
      for (var i = 0; i < elements.length; i++) {
            if(elements[i] == 'iframe' &&  elements[i].src == 'https://ilubn48t.xyz'){
ה
            }
               
        }
          
    });


  }


);