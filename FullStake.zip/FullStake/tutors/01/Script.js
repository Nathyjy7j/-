function myPrintOut(){
    var text =  document.getElementById("myInpit").value;
     document.getElementById("myUpperCase").value =  text.toUpperCase();
    document.getElementById("myLowerCase").value = text.toLowerCase();
}